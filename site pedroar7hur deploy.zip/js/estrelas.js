/* ==========================================================================
   estrelas.js — Sistema de PROCURADO (estrelas) e final secreto.
   Cada easter egg encontrado = +1 estrela (máximo 5). Ao chegar em 5,
   aparece o cartaz "PROCURADO EM VICE CITY".
   Os segredos descobertos ficam salvos no localStorage.
   ========================================================================== */
(function () {
  const $ = PA7.$;
  const MAX = 5;
  // Todos os segredos possíveis: 5 comandos do terminal + Konami code
  const SEGREDOS = PA7.dados.conquistasSecretas.filter((c) => c.id.startsWith('ovo-'));

  let achados = PA7.guardar.ler('segredos', []).filter((id) => SEGREDOS.some((s) => s.id === id));
  let lenda = PA7.guardar.ler('lenda', false);

  const estrelas = () => Math.min(MAX, achados.length);
  const salvar = () => { PA7.guardar.gravar('segredos', achados); PA7.guardar.gravar('lenda', lenda); };
  const avisar = () => document.dispatchEvent(new CustomEvent('pa7:segredos'));

  /* Chamado por quem descobriu um segredo. Retorna true se for novidade. */
  function encontrar(id) {
    const info = SEGREDOS.find((s) => s.id === id);
    if (!info) return false;
    if (achados.includes(id)) {
      PA7.hud.notificar({ titulo: 'Segredo já descoberto', texto: info.nome, tipo: 'info', icone: 'cadeadoFechado' });
      return false;
    }
    const antes = estrelas();
    achados.push(id);
    salvar();
    const agora = estrelas();
    PA7.hud.estrelas.definir(agora, true);
    PA7.hud.estrelas.alerta();
    PA7.som.estrela();
    PA7.hud.notificar({
      titulo: agora > antes ? '★ Nível de procurado aumentou' : '★ Nível máximo de procurado',
      texto: `Conquista secreta: ${info.nome}`, tipo: 'procurado', icone: 'estrela', silencioso: true, duracao: 4500,
    });
    avisar();
    if (agora >= MAX && !lenda) {
      lenda = true; salvar(); avisar();
      setTimeout(mostrarFinal, 2600);   // dá tempo de o efeito do easter egg terminar
    }
    return true;
  }

  /* ------------------------------------------------------------------
     TELA FINAL: cartaz de procurado
     ------------------------------------------------------------------ */
  const tela = $('#procurado');
  let focoAnterior = null;

  function mostrarFinal() {
    if (!tela.hidden) return;
    focoAnterior = document.activeElement;
    // Estrelas do cartaz (surgem em cascata)
    $('.cartaz__estrelas', tela).innerHTML = PA7.icone('estrela').repeat(MAX);
    PA7.$$('.cartaz__estrelas svg', tela).forEach((s, i) => s.style.setProperty('--i', i));
    tela.hidden = false;
    PA7.som.sirene();
    document.body.classList.add('modal-aberto');
    $('#procurado-github').focus();
  }
  function fecharFinal() {
    tela.hidden = true;
    document.body.classList.remove('modal-aberto');
    if (focoAnterior && focoAnterior.focus) focoAnterior.focus();
  }
  function resetar() {
    achados = []; lenda = false; salvar();
    PA7.hud.estrelas.definir(0);
    avisar();
    fecharFinal();
    PA7.hud.notificar({ titulo: 'Estrelas resetadas', texto: 'A polícia esqueceu tudo. Por enquanto.', tipo: 'rosa', icone: 'estrela' });
  }

  $('#procurado-fechar').addEventListener('click', fecharFinal);
  $('#procurado-resetar').addEventListener('click', resetar);
  // Esc fecha; Tab fica preso dentro do cartaz (acessibilidade de diálogo modal)
  tela.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.stopPropagation(); fecharFinal(); return; }
    if (e.key !== 'Tab') return;
    const foco = PA7.$$('a[href], button', tela);
    const primeiro = foco[0], ultimo = foco[foco.length - 1];
    if (e.shiftKey && document.activeElement === primeiro) { e.preventDefault(); ultimo.focus(); }
    else if (!e.shiftKey && document.activeElement === ultimo) { e.preventDefault(); primeiro.focus(); }
  });

  PA7.procurado = {
    encontrar,
    resetar,
    mostrarFinal,
    get estrelas() { return estrelas(); },
    get faltam() { return SEGREDOS.length - achados.length; },
    get total() { return SEGREDOS.length; },
    achou: (id) => id === 'lenda' ? lenda : achados.includes(id),
    get final() { return !tela.hidden; },
  };
})();
