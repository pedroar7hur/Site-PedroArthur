/* ==========================================================================
   audio.js — Efeitos sonoros SINTETIZADOS com a Web Audio API.
   Nenhum arquivo de áudio: cada som é criado na hora com osciladores e ruído.
   O navegador só libera o áudio depois de um clique/toque do usuário, por isso
   o AudioContext é criado "sob demanda" (função contexto()).
   ========================================================================== */
(function () {
  let ac = null;                 // AudioContext compartilhado (efeitos + rádio)
  let saida = null;              // volume geral dos efeitos
  let ruidoBuffer = null;        // 1s de ruído branco reaproveitado (chimbal, caixa, estática)
  let ligado = PA7.guardar.ler('sfx', true);

  /* Cria (ou retoma) o contexto de áudio. Retorna null se o navegador não suportar. */
  function contexto() {
    if (!ac) {
      const Classe = window.AudioContext || window.webkitAudioContext;
      if (!Classe) return null;
      ac = new Classe();
      saida = ac.createGain();
      saida.gain.value = 0.5;
      saida.connect(ac.destination);
      ruidoBuffer = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
      const dados = ruidoBuffer.getChannelData(0);
      for (let i = 0; i < dados.length; i++) dados[i] = Math.random() * 2 - 1;
    }
    if (ac.state === 'suspended') ac.resume();
    return ac;
  }

  /* Toca um tom curto: tipo de onda, frequência (pode deslizar), duração e volume. */
  function tom({ tipo = 'square', de = 440, para = null, dur = 0.08, vol = 0.12, atraso = 0 }) {
    if (!ligado) return;
    const c = contexto(); if (!c) return;
    const t0 = c.currentTime + atraso;
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = tipo;
    osc.frequency.setValueAtTime(de, t0);
    if (para) osc.frequency.exponentialRampToValueAtTime(para, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g).connect(saida);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  /* Rajada de ruído filtrado (para "chiado" de estática e impactos). */
  function ruido({ dur = 0.1, vol = 0.1, freq = 3000, atraso = 0 }) {
    if (!ligado) return;
    const c = contexto(); if (!c) return;
    const t0 = c.currentTime + atraso;
    const fonte = c.createBufferSource();
    fonte.buffer = ruidoBuffer;
    const filtro = c.createBiquadFilter();
    filtro.type = 'bandpass'; filtro.frequency.value = freq; filtro.Q.value = 0.8;
    const g = c.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    fonte.connect(filtro).connect(g).connect(saida);
    fonte.start(t0);
    fonte.stop(t0 + dur + 0.02);
  }

  PA7.som = {
    contexto,
    get buffer() { return ruidoBuffer; },
    get ativo() { return ligado; },
    definirAtivo(v) { ligado = !!v; PA7.guardar.gravar('sfx', ligado); },

    /* --- Sons da interface --- */
    clique()   { tom({ tipo: 'square', de: 880, para: 1320, dur: 0.05, vol: 0.06 }); },
    tick()     { tom({ tipo: 'triangle', de: 1500, para: 1100, dur: 0.03, vol: 0.05 }); },
    abrir()    { tom({ tipo: 'sawtooth', de: 300, para: 900, dur: 0.14, vol: 0.05 }); tom({ tipo: 'square', de: 900, para: 1500, dur: 0.08, vol: 0.04, atraso: 0.08 }); },
    voltar()   { tom({ tipo: 'sawtooth', de: 800, para: 280, dur: 0.12, vol: 0.05 }); },
    notificar(){ tom({ tipo: 'sine', de: 988, dur: 0.12, vol: 0.12 }); tom({ tipo: 'sine', de: 1319, dur: 0.22, vol: 0.12, atraso: 0.1 }); },
    dinheiro() { tom({ tipo: 'square', de: 1319, dur: 0.06, vol: 0.06 }); tom({ tipo: 'square', de: 1760, dur: 0.14, vol: 0.06, atraso: 0.06 }); },
    erro()     { tom({ tipo: 'sawtooth', de: 220, para: 110, dur: 0.25, vol: 0.1 }); },
    teclar()   { ruido({ dur: 0.02, vol: 0.05, freq: 5000 }); },
    inicio()   { [261.6, 329.6, 392, 523.3].forEach((f, i) => tom({ tipo: 'sawtooth', de: f, dur: 0.5, vol: 0.07, atraso: i * 0.07 })); },
    estrela()  { [659, 880, 1175, 1568].forEach((f, i) => tom({ tipo: 'square', de: f, dur: 0.16, vol: 0.07, atraso: i * 0.07 })); },

    /* "MISSÃO CUMPRIDA": acorde ascendente com brilho no final. */
    fanfarra() {
      [196, 247, 294, 392].forEach((f, i) => tom({ tipo: 'sawtooth', de: f, dur: 0.9, vol: 0.06, atraso: i * 0.09 }));
      tom({ tipo: 'triangle', de: 784, dur: 1.2, vol: 0.09, atraso: 0.4 });
      ruido({ dur: 0.5, vol: 0.05, freq: 6000, atraso: 0.4 });
    },

    /* Sirene de polícia: oscilador que sobe e desce duas vezes (~2s). */
    sirene() {
      if (!ligado) return;
      const c = contexto(); if (!c) return;
      const t0 = c.currentTime;
      const osc = c.createOscillator();
      const g = c.createGain();
      osc.type = 'sawtooth';
      for (let i = 0; i < 4; i++) {
        osc.frequency.linearRampToValueAtTime(i % 2 ? 640 : 1080, t0 + 0.25 + i * 0.45);
      }
      osc.frequency.setValueAtTime(640, t0);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.09, t0 + 0.1);
      g.gain.setValueAtTime(0.09, t0 + 1.6);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 2.1);
      const filtro = c.createBiquadFilter();
      filtro.type = 'lowpass'; filtro.frequency.value = 2400;
      osc.connect(filtro).connect(g).connect(saida);
      osc.start(t0); osc.stop(t0 + 2.2);
    },
  };

  /* Som de clique automático em todo botão/link (delegação de eventos). */
  document.addEventListener('click', (e) => {
    if (e.target.closest('button, a[href], [role="button"], .app-icone, .minimapa__blip')) PA7.som.clique();
  }, true);
})();
