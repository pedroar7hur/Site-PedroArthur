/* ==========================================================================
   icones.js — Biblioteca de ícones SVG PRÓPRIOS (nenhum emoji como ícone).
   Todos desenhados em uma grade 24x24, traço de 1.75px, pontas arredondadas,
   para manter o mesmo estilo visual em todo o site.
   Uso: PA7.icone('terminal')  ->  string de <svg> pronta para innerHTML.
   ========================================================================== */
window.PA7 = window.PA7 || {};

(function () {
  /* Cada entrada guarda só o "miolo" do SVG (paths, círculos, retângulos). */
  const MIOLO = {
    /* ----- Apps do celular ----- */
    ficha: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="9" cy="11" r="2"/><path d="M5.8 16.2c.6-1.5 1.9-2.4 3.2-2.4s2.6.9 3.2 2.4"/><path d="M14.5 10h4M14.5 13.5h3"/>',
    habilidades: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
    inventario: '<path d="M6.5 9.5a5.5 5.5 0 0 1 11 0V18a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2z"/><rect x="9" y="14" width="6" height="4" rx="1"/><path d="M10 4.2v-.7a2 2 0 0 1 4 0v.7"/>',
    missoes: '<path d="M5 21V3.5"/><path d="M5 4.5h12.5l-2.2 3.8 2.2 3.8H5"/>',
    conquistas: '<path d="M8 4h8v5a4 4 0 0 1-8 0z"/><path d="M8 6H5v1.5A3 3 0 0 0 8 10.5M16 6h3v1.5a3 3 0 0 1-3 3"/><path d="M12 13v5M8.5 20.5h7M10 18h4"/>',
    terminal: '<rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M7 10l3 2.5L7 15M12.5 15.5H17"/>',
    radio: '<rect x="3" y="8.5" width="18" height="11.5" rx="2.5"/><circle cx="16" cy="14.2" r="3"/><path d="M6.5 13h4M6.5 16h4M7 8.5l9.5-5"/>',
    github: '<path d="M6 3.5v11"/><circle cx="18" cy="6.5" r="2.5"/><circle cx="6" cy="18" r="2.5"/><path d="M18 9a8 8 0 0 1-8 8H8.5"/>',

    feed: '<path d="M4 5.5h16a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-8l-4.5 3.5v-3.5H4a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1z"/><path d="M7.5 9.5h9M7.5 12.5h5.5"/>',
    coracao: '<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.4a4.3 4.3 0 0 1 7.5 2.4C19.5 15.4 12 20 12 20z"/>',
    comentario: '<path d="M4 5h16v11H9.5L5 19.5V16H4z"/>',
    compartilhar: '<path d="M4 12v6a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-6M12 15V3.5M7.5 8L12 3.5 16.5 8"/>',

    /* ----- Habilidades ----- */
    html: '<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M13.5 6l-3 12"/>',
    css: '<path d="M9 4H8a2 2 0 0 0-2 2v3a2 2 0 0 1-2 2 2 2 0 0 1 2 2v3a2 2 0 0 0 2 2h1M15 4h1a2 2 0 0 1 2 2v3a2 2 0 0 0 2 2 2 2 0 0 0-2 2v3a2 2 0 0 1-2 2h-1"/>',
    js: '<path d="M13 3L5 13.5h6L10 21l8-10.5h-6z"/>',
    ia: '<path d="M11 3.5l1.7 4.6L17.3 9.8l-4.6 1.7L11 16.1l-1.7-4.6L4.7 9.8l4.6-1.7z"/><path d="M18.5 15l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z"/>',
    video: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M10.2 9.4v5.2l4.4-2.6z"/><path d="M3 9h2M3 15h2M19 9h2M19 15h2"/>',
    anuncio: '<path d="M4 10v4h3l7 4V6L7 10z"/><path d="M17.5 9.2a4 4 0 0 1 0 5.6M7 14l1 5h2.5l-1-4.4"/>',
    automacao: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="6.6"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1"/>',
    analitico: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21M8 12.5v-1.8M10.5 12.5V8.6M13 12.5V9.8"/>',
    estrategia: '<path d="M6 20.5h12M8 20.5V10h8v10.5M7 10V6h2v1.6h2V6h2v1.6h2V6h2v4"/>',
    adapta: '<path d="M4 12a8 8 0 0 1 13.7-5.7L20 8.5M20 4v4.5h-4.5M20 12a8 8 0 0 1-13.7 5.7L4 15.5M4 20v-4.5h4.5"/>',
    livro: '<path d="M3 6.5C5 5 8 5 12 7c4-2 7-2 9-.5V19c-2-1.5-5-1.5-9 .5-4-2-7-2-9-.5z"/><path d="M12 7v12.5"/>',
    foguete: '<path d="M12 3c3 2 5 5.5 5 9.5L15 15H9l-2-2.5C7 8.5 9 5 12 3z"/><circle cx="12" cy="9.5" r="1.6"/><path d="M9 15l-2 4 3-1M15 15l2 4-3-1M12 17.5V21"/>',
    ideia: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.3 1 2.1h5c0-.8.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',

    /* ----- Inventário ----- */
    bola: '<circle cx="12" cy="12" r="9"/><path d="M12 8.6l3 2.2-1.1 3.5h-3.8L9 10.8z"/><path d="M12 8.6V3.2M15 10.8l5.1-1.7M13.9 14.3l3.1 4.2M10.1 14.3l-3.1 4.2M9 10.8L3.9 9.1"/>',
    maleta: '<rect x="3" y="8" width="18" height="12" rx="2"/><path d="M9 8V6a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13.5h18M11 13.5v2h2v-2"/>',
    carro: '<path d="M3.5 16v-3.3c0-.6.2-1.1.6-1.5L6.3 8A2 2 0 0 1 7.9 7h8.2a2 2 0 0 1 1.6 1l2.2 3.2c.4.4.6.9.6 1.5V16z"/><path d="M6.5 11.5h11"/><circle cx="7.5" cy="16.5" r="2"/><circle cx="16.5" cy="16.5" r="2"/>',
    halter: '<path d="M6 7.5v9M18 7.5v9M3 10v4M21 10v4M6 12h12"/>',
    dinheiro: '<rect x="2.5" y="6.5" width="19" height="11" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 10v.01M18 14v.01"/>',
    caneca: '<path d="M5 8h10v11a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z"/><path d="M15 10h2.5a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H15M8.5 11v6M11.5 11v6"/><path d="M5 8a2.2 2.2 0 0 1 2.2-2.2c.5-1.4 2.2-2 3.4-1.2A2.5 2.5 0 0 1 15 8"/>',
    peixe: '<path d="M2.5 12C5 8 9 7 13 8.5c1.5.6 3 1.6 4 3.5-1 1.9-2.5 2.9-4 3.5C9 17 5 16 2.5 12z"/><path d="M17 12l4.5-3.5v7z"/><path d="M7.5 11v.01"/>',

    /* ----- Conquistas ----- */
    capelo: '<path d="M2.5 9L12 4.5 21.5 9 12 13.5z"/><path d="M6.5 11.2V16c0 1.2 2.5 2.8 5.5 2.8s5.5-1.6 5.5-2.8v-4.8M21.5 9v5"/>',
    contrato: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 14.5l2 2 4-4.2"/>',
    escudo: '<path d="M12 3l8 3.5v5.2c0 4.5-3.2 7.8-8 9.3-4.8-1.5-8-4.8-8-9.3V6.5z"/><path d="M8.5 11.2L12 9l3.5 2.2M8.5 14.8L12 12.6l3.5 2.2"/>',
    trigo: '<path d="M12 21V4M12 8c-2-.3-3-1.7-3-3.5 2 .2 3 1.5 3 3.5zM12 8c2-.3 3-1.7 3-3.5-2 .2-3 1.5-3 3.5zM12 13c-2-.3-3-1.7-3-3.5 2 .2 3 1.5 3 3.5zM12 13c2-.3 3-1.7 3-3.5-2 .2-3 1.5-3 3.5zM12 18c-2-.3-3-1.7-3-3.5 2 .2 3 1.5 3 3.5zM12 18c2-.3 3-1.7 3-3.5-2 .2-3 1.5-3 3.5z"/>',
    chama: '<path d="M12 3c1 3 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3.2 2-4 0 1.5.8 2.2 1.5 2.5C10 8.5 10.5 5.5 12 3z"/>',
    globo: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z"/>',
    cadeado: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3M12 15v2"/>',
    bug: '<path d="M8.5 10h7v5a3.5 3.5 0 0 1-7 0z"/><path d="M9.5 7.5a2.5 2.5 0 0 1 5 0M5 10l3.5 1M5 15l3.5-1M19 10l-3.5 1M19 15l-3.5-1M12 10v8.5M10 5L9 3.5M14 5l1-1.5"/>',
    camadas: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 12.5l9 5 9-5M3 17l9 5 9-5"/>',
    cafe: '<path d="M5 9h11v6a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4z"/><path d="M16 10.5h1.5a2.5 2.5 0 0 1 0 5H16M8 3.5c0 1 1 1.3 1 2.3M12 3.5c0 1 1 1.3 1 2.3"/>',
    sirene: '<path d="M7 19v-6a5 5 0 0 1 10 0v6M5 19h14M12 3v2M4.5 6.5L6 8M19.5 6.5L18 8M3 12h2M19 12h2"/>',
    controle: '<rect x="2.5" y="7.5" width="19" height="10" rx="5"/><path d="M7.5 10.5v4M5.5 12.5h4"/><circle cx="15.5" cy="11.5" r=".9"/><circle cx="18" cy="13.5" r=".9"/>',
    coroa: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/><path d="M5.5 21.5h13"/>',

    /* ----- Interface ----- */
    voltar: '<path d="M15 5l-7 7 7 7"/>',
    fechar: '<path d="M6 6l12 12M18 6L6 18"/>',
    cadeadoFechado: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    estrela: '<path d="M12 2.8l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.7l-5.9 3.1 1.2-6.5L2.5 9.7l6.6-.9z"/>',
    som: '<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    mudo: '<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
    ligar: '<path d="M12 3v8"/><path d="M6.6 6.6a8 8 0 1 0 10.8 0"/>',
    play: '<path d="M8 5.5v13l11-6.5z"/>',
    pausa: '<path d="M8 5.5v13M16 5.5v13"/>',
    externo: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
    celular: '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/>',
    guardar: '<path d="M6 9l6 6 6-6"/>',
    nota: '<path d="M9 18V5.5l10-2V16"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
    sinal: '<path d="M4 19v-3M9 19v-6M14 19V9M19 19V5"/>',
    mira: '<circle cx="12" cy="12" r="7.5"/><circle cx="12" cy="12" r="1.1"/><path d="M12 2.5v6.5M12 15v6.5M2.5 12H9M15 12h6.5"/>',
  };

  /* Devolve o <svg> completo. `extra` = classes CSS opcionais. */
  PA7.icone = function (nome, extra) {
    const miolo = MIOLO[nome] || MIOLO.estrela;
    return '<svg class="icone' + (extra ? ' ' + extra : '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + miolo + '</svg>';
  };

  /* Utilitários pequenos usados por vários scripts. */
  PA7.$ = (seletor, raiz) => (raiz || document).querySelector(seletor);
  PA7.$$ = (seletor, raiz) => Array.from((raiz || document).querySelectorAll(seletor));
  PA7.espera = (ms) => new Promise((ok) => setTimeout(ok, ms));
  PA7.reduzMovimento = window.matchMedia('(prefers-reduced-motion: reduce)');
  PA7.ehCelular = () => window.matchMedia('(max-width: 820px)').matches;
  PA7.pad = (n, tam) => String(n).padStart(tam, '0');

  /* localStorage sempre protegido: pode estar bloqueado (modo anônimo etc.). */
  PA7.guardar = {
    ler(chave, padrao) {
      try {
        const bruto = localStorage.getItem('pa7:' + chave);
        return bruto === null ? padrao : JSON.parse(bruto);
      } catch (e) { return padrao; }
    },
    gravar(chave, valor) {
      try { localStorage.setItem('pa7:' + chave, JSON.stringify(valor)); } catch (e) { /* ignora */ }
    },
    apagar(chave) {
      try { localStorage.removeItem('pa7:' + chave); } catch (e) { /* ignora */ }
    },
  };
})();
