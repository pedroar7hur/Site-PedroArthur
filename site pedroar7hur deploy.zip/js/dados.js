/* ==========================================================================
   dados.js — Todo o CONTEÚDO do site em um só lugar.
   Para mudar um texto, uma habilidade ou uma missão, é só editar aqui.
   Tudo fica dentro do namespace global `PA7` (os scripts são clássicos, sem
   módulos, então o site também funciona abrindo o index.html direto).
   ========================================================================== */
window.PA7 = window.PA7 || {};

PA7.dados = {
  /* ---------- Identidade ---------- */
  nome: 'Pedro Arthur',
  nickname: 'PedroAr7hur',
  classe: 'Estudante de ADS · Criador de sistemas',
  bio: 'Estudo sistemas de noite e construo negócios de dia. Onde a maioria vê rotina, eu vejo oportunidade.',
  status: 'Online, provavelmente começando um projeto novo.',
  github: 'https://github.com/pedroar7hur',

  /* ---------- Atributos (0 a 100) ---------- */
  atributos: [
    { id: 'criatividade', nome: 'Criatividade', valor: 88 },
    { id: 'logica',       nome: 'Lógica', valor: 86 },
    { id: 'foco',         nome: 'Foco', valor: 89 },
    { id: 'eficiencia',   nome: 'Eficiência', valor: 89 },
    { id: 'prompt',       nome: 'Prompt Engineering', valor: 85 },
    { id: 'bug',          nome: 'Resistência a Bug', valor: 79 },
    { id: 'cafe',         nome: 'Café no Sangue', valor: 97 },
    { id: 'maquina',      nome: 'Fé no "Na Minha Máquina Funciona"', valor: 100, transborda: true },
  ],

  /* ---------- Habilidades (icone = nome em PA7.icones) ---------- */
  habilidades: {
    tecnicas: [
      { nome: 'HTML', icone: 'html', dica: 'A base de tudo. Já fechei tag que nem tinha sido aberta.' },
      { nome: 'CSS', icone: 'css', dica: 'Centralizar uma div: missão lendária, mas completa.' },
      { nome: 'JavaScript', icone: 'js', dica: 'Faz tudo funcionar. E às vezes quebrar também.' },
      { nome: 'IA', icone: 'ia', dica: 'Eu pergunto, ela responde. Às vezes a gente até concorda.' },
      { nome: 'Edição de Vídeo', icone: 'video', dica: 'Corto o que sobra e deixo o que vende.' },
      { nome: 'Meta Ads', icone: 'anuncio', dica: 'Transformo R$ 1 em atenção. Com sorte, em venda.' },
      { nome: 'Automação de Processos', icone: 'automacao', dica: 'Fiz duas vezes? Na terceira um robô faz.' },
    ],
    mentais: [
      { nome: 'Pensamento Analítico', icone: 'analitico', dica: 'Primeiro os dados, depois a opinião.' },
      { nome: 'Pensamento Estratégico', icone: 'estrategia', dica: 'Penso três jogadas à frente. A quarta eu chuto.' },
      { nome: 'Adaptabilidade', icone: 'adapta', dica: 'Mudou o plano? Ótimo, eu já estava no plano B.' },
      { nome: 'Aprendizagem Rápida', icone: 'livro', dica: 'Vi um tutorial e já virei dev. Quase.' },
      { nome: 'Capacidade de Execução', icone: 'foguete', dica: 'Ideia sem execução é só devaneio. Aqui sai do papel.' },
      { nome: 'Visão de Negócio', icone: 'ideia', dica: 'Todo problema é um produto que ainda não tem preço.' },
    ],
  },

  /* ---------- Inventário ---------- */
  inventario: [
    { nome: 'Futebol', icone: 'bola', frase: 'Domingo é sagrado. Até bug espera o apito final.' },
    { nome: 'Vender', icone: 'maleta', frase: 'Se existe cliente, existe negócio.' },
    { nome: 'Carros', icone: 'carro', frase: 'Paixão que não cabe na planilha.' },
    { nome: 'Treinar', icone: 'halter', frase: 'Corpo em dia, cabeça no código.' },
    { nome: 'Tiro esportivo', icone: 'mira', detalhe: 'calibre 12', frase: 'Foco total e mão firme. Mira no alvo.' },
    { nome: 'Fazer e gastar dinheiro', icone: 'dinheiro', frase: 'O primeiro é mais fácil que o segundo.' },
    { nome: 'Tomar uma', icone: 'caneca', frase: 'Com moderação e boa companhia.' },
    { nome: 'Pescar', icone: 'peixe', frase: 'O único lugar onde esperar é estratégia.' },
  ],
  jogos: ['GTA', 'FIFA', 'Call of Duty', 'PUBG', 'NBA 2K'],
  ferramentas: ['VS Code', 'Claude', 'ChatGPT', 'Figma', 'Miro', 'e entre outras...'],

  /* ---------- Missões ---------- */
  missoes: {
    concluidas: [
      'Entrou na faculdade',
      'SaaS lançado',
      'Primeiros clientes',
      'Experiência no Exército Brasileiro',
      'Trabalhou no setor agropecuário',
      'Saiu da zona de conforto por decisão própria',
      'Conquistou o primeiro cliente internacional',
    ],
    andamento: [
      { titulo: 'Terminar ADS' },
      { titulo: 'Escalar os projetos atuais' },
      { titulo: 'Transformar a lista de ideias em negócios reais', nota: 'A lista cresce mais rápido que a agenda.' },
    ],
    principal: 'Construir um império de negócios digitais',
  },

  /* ---------- Conquistas ----------
     As 7 primeiras vêm das missões concluídas (já desbloqueadas).
     As "secretas" só aparecem quando o visitante acha o easter egg com o mesmo `id`. */
  conquistas: [
    { id: 'matricula', nome: 'Matrícula Confirmada', desc: 'Entrou na faculdade', icone: 'capelo', nivel: 'bronze' },
    { id: 'deploy', nome: 'Deploy em Produção', desc: 'Lançou um SaaS', icone: 'foguete', nivel: 'ouro' },
    { id: 'contrato', nome: 'Primeiro Contrato', desc: 'Primeiros clientes', icone: 'contrato', nivel: 'prata' },
    { id: 'militar', nome: 'Disciplina Militar', desc: 'Exército Brasileiro', icone: 'escudo', nivel: 'prata' },
    { id: 'campo', nome: 'Raiz no Campo', desc: 'Setor agropecuário', icone: 'trigo', nivel: 'bronze' },
    { id: 'zona', nome: 'Sem Zona de Conforto', desc: 'Decisão própria', icone: 'chama', nivel: 'prata' },
    { id: 'mundo', nome: 'Internacional', desc: 'Primeiro cliente de fora do país', icone: 'globo', nivel: 'ouro' },
  ],
  conquistasSecretas: [
    { id: 'ovo-ideia', nome: 'Sudo Ideia', desc: 'Pediu permissão de administrador para ter uma ideia.', icone: 'cadeado' },
    { id: 'ovo-deploy', nome: 'Na Minha Máquina Funciona', desc: 'Foi pro deploy e a produção discordou.', icone: 'bug' },
    { id: 'ovo-ideias', nome: 'Agenda Cheia', desc: 'Descobriu que a lista de ideias não para de crescer.', icone: 'camadas' },
    { id: 'ovo-cafe', nome: 'Sangue de Cafeína', desc: 'Recarregou a barra de café até o limite.', icone: 'cafe' },
    { id: 'ovo-rm', nome: 'Procurado pela Lei', desc: 'Tentou apagar tudo. A polícia foi avisada.', icone: 'sirene' },
    { id: 'ovo-konami', nome: 'Código Clássico', desc: 'Lembrou do truque mais famoso dos videogames.', icone: 'controle' },
    { id: 'lenda', nome: 'Lenda de Vice City', desc: 'Chegou às 5 estrelas de procurado.', icone: 'coroa' },
  ],

  /* ---------- Frases ---------- */
  frasesCarregamento: [
    'Compilando café...',
    'Corrigindo bug que não existe...',
    'Convencendo o CSS a centralizar a div...',
    'Procurando o ponto e vírgula perdido...',
    'Transformando ideia em negócio...',
    'Funciona na minha máquina. Carregando a sua...',
  ],
  locutor: 'Você está ouvindo PA7 FM. Hoje: 0 bugs, 3 cafés, 12 ideias novas.',
};
