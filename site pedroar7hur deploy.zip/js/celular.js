/* ==========================================================================
   celular.js — O CELULAR in-game: tela inicial, navegação entre apps e o
   conteúdo de cada app (Ficha, Habilidades, Inventário, Missões, Conquistas,
   Rádio e GitHub). O Terminal é uma janela própria (terminal.js).
   Também contém a roda radial do inventário (segurar TAB) e o banner
   "MISSÃO CUMPRIDA".
   ========================================================================== */
(function () {
  const { $, $$, icone, dados } = Object.assign({}, PA7, { dados: PA7.dados });

  /* ------------------------------------------------------------------
     Lista de apps (ordem = ordem da grade e dos blips do minimapa)
     ------------------------------------------------------------------ */
  const APPS = [
    { id: 'ficha', nome: 'Ficha', icone: 'ficha', c1: '#ff4f9a', c2: '#ff8f6b' },
    { id: 'habilidades', nome: 'Habilidades', icone: 'habilidades', c1: '#ffb347', c2: '#ff8f6b' },
    { id: 'inventario', nome: 'Inventário', icone: 'inventario', c1: '#ffb347', c2: '#8a5cf6' },
    { id: 'missoes', nome: 'Missões', icone: 'missoes', c1: '#6fdc8c', c2: '#ffb347' },
    { id: 'conquistas', nome: 'Conquistas', icone: 'conquistas', c1: '#ffb347', c2: '#ff4f9a' },
    { id: 'terminal', nome: 'Terminal', icone: 'terminal', c1: '#1b0f36', c2: '#0f5a3a', terminal: true },
    { id: 'radio', nome: 'Rádio', icone: 'radio', c1: '#8a5cf6', c2: '#ff4f9a' },
    { id: 'feed', nome: 'Feed', icone: 'feed', c1: '#2a2a33', c2: '#2a2a33' },
    { id: 'github', nome: 'GitHub', icone: 'github', c1: '#2a1650', c2: '#8a5cf6' },
  ];

  const elCelular = $('#celular');
  const elInicio = $('#inicio');
  const elApps = $('#apps');
  let appAtual = null;          // id do app aberto (null = tela inicial)
  let ultimoBotao = null;       // botão que abriu o app (para devolver o foco)
  const jaAbertos = new Set();  // apps já abertos nesta visita

  /* ------------------------------------------------------------------
     RELÓGIO REAL (barra de status + tela inicial)
     ------------------------------------------------------------------ */
  function atualizarRelogio() {
    const agora = new Date();
    const hora = agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    $('#hora-status').textContent = hora;
    $('#hora-inicio').textContent = hora;
    const data = agora.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
    $('#data-inicio').textContent = data.charAt(0).toUpperCase() + data.slice(1);
  }

  /* ------------------------------------------------------------------
     Construção: grade da tela inicial e "cascas" de cada app
     ------------------------------------------------------------------ */
  function montarGrade() {
    const grade = $('#grade-apps');
    APPS.forEach((app, i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'app-icone';
      b.dataset.app = app.id;
      b.setAttribute('role', 'listitem');
      b.style.cssText = `--c1:${app.c1};--c2:${app.c2};--i:${i}`;
      b.innerHTML = `<span class="app-icone__tile">${icone(app.icone)}</span><span class="app-icone__nome">${app.nome}</span>`;
      b.addEventListener('click', () => abrir(app.id, b));
      grade.appendChild(b);
    });
  }

  function montarApps() {
    APPS.filter((a) => !a.terminal).forEach((app) => {
      const s = document.createElement('section');
      s.className = 'app';
      s.id = 'app-' + app.id;
      s.setAttribute('aria-labelledby', 'titulo-' + app.id);
      s.inert = true;
      s.style.cssText = `--c1:${app.c1};--c2:${app.c2}`;
      s.innerHTML = `
        <header class="app__topo">
          <button class="app__voltar" type="button" aria-label="Voltar à tela inicial">${icone('voltar')}<span>Início</span></button>
          <h2 class="app__titulo" id="titulo-${app.id}" tabindex="-1"><span class="app__titulo-icone">${icone(app.icone)}</span>${app.nome}</h2>
        </header>
        <div class="app__corpo"></div>`;
      $('.app__voltar', s).addEventListener('click', voltar);
      elApps.appendChild(s);
      RENDER[app.id]($('.app__corpo', s), s);
    });
  }

  /* ------------------------------------------------------------------
     NAVEGAÇÃO
     ------------------------------------------------------------------ */
  function abrir(id, botao) {
    mostrar();
    if (id === 'terminal') { PA7.terminal.abrir(); return; }
    if (appAtual === id) return;
    if (appAtual) fecharAtual();
    const app = $('#app-' + id);
    if (!app) return;
    ultimoBotao = botao || $(`.app-icone[data-app="${id}"]`);
    appAtual = id;
    app.inert = false;
    app.classList.remove('aberto'); void app.offsetWidth;   // reinicia as animações internas
    app.classList.add('aberto');
    elInicio.classList.add('recuado'); elInicio.inert = true;
    PA7.som.abrir();
    $('.app__corpo', app).scrollTop = 0;
    if (ABRIR[id]) ABRIR[id](app, !jaAbertos.has(id));
    if (!jaAbertos.has(id)) { jaAbertos.add(id); PA7.hud.dinheiro.somar(250); }
    setTimeout(() => { if (appAtual === id) $('.app__titulo', app).focus({ preventScroll: true }); }, 380);
    document.body.dataset.app = id;
  }
  function fecharAtual() {
    const app = $('#app-' + appAtual);
    if (app) { app.classList.remove('aberto'); app.inert = true; }
    appAtual = null; delete document.body.dataset.app;
    fecharRoda();
  }
  function voltar() {
    if (!appAtual) return false;
    fecharAtual();
    elInicio.classList.remove('recuado'); elInicio.inert = false;
    PA7.som.voltar();
    if (ultimoBotao) ultimoBotao.focus({ preventScroll: true });
    return true;
  }

  /* Guardar / mostrar o celular (somente desktop; no celular de verdade ele é a tela inteira) */
  function guardar() {
    if (PA7.ehCelular()) return false;
    if (appAtual) voltar();
    elCelular.classList.add('guardado'); elCelular.inert = true;
    $('#btn-celular-hud').hidden = false;
    PA7.som.voltar();
    return true;
  }
  function mostrar() {
    if (!elCelular.classList.contains('guardado')) return;
    elCelular.classList.remove('guardado'); elCelular.inert = false;
    $('#btn-celular-hud').hidden = true;
    PA7.som.abrir();
  }

  /* ------------------------------------------------------------------
     CONTEÚDO DE CADA APP
     ------------------------------------------------------------------ */
  const RENDER = {};   // id → função que monta o conteúdo UMA vez
  const ABRIR = {};    // id → função executada a cada abertura (reinicia animações)

  /* ===== FICHA ===== */
  RENDER.ficha = (corpo) => {
    // Código de barras decorativo, gerado com números "aleatórios" fixos
    let barras = '', x = 0, seed = 7;
    while (x < 150) { seed = (seed * 9301 + 49297) % 233280; const l = 1 + (seed % 3); barras += `<rect x="${x}" y="0" width="${l}" height="22"/>`; x += l + 1 + (seed % 2); }
    corpo.innerHTML = `
      <article class="cnh" id="cnh">
        <div class="cnh__holo" aria-hidden="true"></div>
        <header class="cnh__topo"><span>Estado de Vice City</span><span>Carteira de Motorista</span></header>
        <div class="cnh__miolo">
          <figure class="cnh__foto">
            <picture>
              <source srcset="assets/avatar-400.webp" type="image/webp">
              <img src="assets/avatar-400.png" alt="Retrato ilustrado de PedroAr7hur em Vice City" width="400" height="500" decoding="async">
            </picture>
          </figure>
          <dl class="cnh__campos">
            <div><dt>Nome</dt><dd>${dados.nome}</dd></div>
            <div><dt>Apelido</dt><dd class="neon">${dados.nickname}</dd></div>
            <div><dt>Classe</dt><dd>${dados.classe}</dd></div>
            <div class="cnh__duplo"><div><dt>Categoria</dt><dd>A · D · S</dd></div><div><dt>Validade</dt><dd>∞</dd></div></div>
          </dl>
        </div>
        <footer class="cnh__rodape"><svg viewBox="0 0 150 22" preserveAspectRatio="none" aria-hidden="true" focusable="false">${barras}</svg><span>Nº 0007 · PA7</span></footer>
      </article>
      <figure class="bio"><blockquote>“${dados.bio}”</blockquote></figure>
      <p class="ficha__status"><i class="ponto-online" aria-hidden="true"></i><span><b>Status:</b> ${dados.status}</span></p>
      <h3 class="app__secao">Atributos</h3>
      <ul class="atributos" id="lista-atributos">
        ${dados.atributos.map((a, i) => `
          <li class="atributo${a.transborda ? ' atributo--transborda' : ''}" data-id="${a.id}" style="--i:${i}">
            <div class="atributo__linha"><span class="atributo__nome">${a.nome}</span><span class="atributo__valor"><b class="atributo__num">0</b>${a.transborda ? '<em>OVERFLOW</em>' : ''}</span></div>
            <div class="barra" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${a.valor}" aria-label="${a.nome}">
              <div class="barra__fill"></div>${a.transborda ? '<div class="barra__excesso"></div>' : ''}
            </div>
          </li>`).join('')}
      </ul>`;
    iniciarHolografico($('#cnh', corpo));
  };
  /* Efeito holográfico + inclinação 3D do cartão seguindo o mouse/dedo */
  function iniciarHolografico(cartao) {
    function mover(e) {
      const r = cartao.getBoundingClientRect();
      const nx = (e.clientX - r.left) / r.width, ny = (e.clientY - r.top) / r.height;
      cartao.style.setProperty('--mx', (nx * 100).toFixed(1) + '%');
      cartao.style.setProperty('--my', (ny * 100).toFixed(1) + '%');
      if (!PA7.reduzMovimento.matches) {
        cartao.style.setProperty('--rx', ((0.5 - ny) * 12).toFixed(2) + 'deg');
        cartao.style.setProperty('--ry', ((nx - 0.5) * 16).toFixed(2) + 'deg');
      }
    }
    cartao.addEventListener('pointerenter', () => cartao.classList.add('holo'));
    cartao.addEventListener('pointermove', mover);
    cartao.addEventListener('pointerleave', () => {
      cartao.classList.remove('holo');
      ['--rx', '--ry'].forEach((p) => cartao.style.removeProperty(p));
    });
  }
  /* Preenche as barras (com mola) e faz os números contarem de 0 até o valor. */
  ABRIR.ficha = (app) => {
    $$('.atributo', app).forEach((li, i) => {
      const a = dados.atributos.find((x) => x.id === li.dataset.id);
      li.style.setProperty('--v', a.valor / 100);
      $('.barra', li).setAttribute('aria-valuenow', a.valor);
      contar($('.atributo__num', li), a.valor, 1100, 300 + i * 90);
    });
  };
  function contar(el, alvo, dur, atraso) {
    if (PA7.reduzMovimento.matches) { el.textContent = alvo; return; }
    el.textContent = '0';
    setTimeout(() => {
      const t0 = performance.now();
      (function passo(agora) {
        const t = Math.min(1, (agora - t0) / dur);
        el.textContent = Math.round(alvo * (1 - Math.pow(1 - t, 3)));
        if (t < 1) requestAnimationFrame(passo);
      })(t0);
    }, atraso);
  }

  /* ===== HABILIDADES ===== */
  RENDER.habilidades = (corpo) => {
    const grupo = (titulo, lista, ini) => `
      <section class="skills__grupo">
        <h3 class="app__secao">${titulo}</h3>
        <div class="skills__grade">
          ${lista.map((s, i) => `
            <button class="skill" type="button" style="--i:${ini + i}" data-nome="${s.nome}" data-dica="${s.dica}" data-icone="${s.icone}">
              <span class="skill__hex">${icone(s.icone)}</span>
              <span class="skill__nome">${s.nome}</span>
            </button>`).join('')}
        </div>
      </section>`;
    corpo.innerHTML = `
      <p class="skills__resumo"><b>${dados.habilidades.tecnicas.length + dados.habilidades.mentais.length}</b> de ${dados.habilidades.tecnicas.length + dados.habilidades.mentais.length} habilidades desbloqueadas</p>
      ${grupo('Técnicas', dados.habilidades.tecnicas, 0)}
      ${grupo('Mentais', dados.habilidades.mentais, dados.habilidades.tecnicas.length)}
      <aside class="skills__dica" id="skill-dica" aria-live="polite"><span class="skills__dica-icone">${icone('habilidades')}</span><div><p class="skills__dica-nome">Escolha uma habilidade</p><p class="skills__dica-texto">Toque (ou passe o mouse) em um badge para ver o que ele diz.</p></div></aside>`;
    const painel = $('#skill-dica', corpo);
    function selecionar(btn) {
      $$('.skill', corpo).forEach((b) => b.classList.toggle('ativo', b === btn));
      $('.skills__dica-icone', painel).innerHTML = icone(btn.dataset.icone);
      $('.skills__dica-nome', painel).textContent = btn.dataset.nome;
      $('.skills__dica-texto', painel).textContent = btn.dataset.dica;
      painel.classList.remove('troca'); void painel.offsetWidth; painel.classList.add('troca');
    }
    $$('.skill', corpo).forEach((b) => {
      b.addEventListener('click', () => selecionar(b));
      b.addEventListener('focus', () => selecionar(b));
      b.addEventListener('mouseenter', () => { if (matchMedia('(hover:hover)').matches) { selecionar(b); PA7.som.tick(); } });
    });
  };

  /* ===== INVENTÁRIO ===== */
  RENDER.inventario = (corpo) => {
    corpo.innerHTML = `
      <p class="inv__dica"><span class="so-desktop-inline">Segure <kbd>Tab</kbd> para abrir a roda de itens</span><button class="inv__roda" id="btn-roda" type="button">${icone('mira')}Abrir roda</button></p>
      <ul class="inv__grade">
        ${dados.inventario.map((it, i) => `
          <li class="item" style="--i:${i}" tabindex="0" aria-label="${it.nome}${it.detalhe ? ' (' + it.detalhe + ')' : ''}. ${it.frase}">
            <span class="item__icone">${icone(it.icone)}</span>
            <span class="item__nome">${it.nome}</span>
            ${it.detalhe ? `<span class="item__detalhe">${it.detalhe}</span>` : ''}
            <span class="item__frase">${it.frase}</span>
          </li>`).join('')}
      </ul>
      <h3 class="app__secao">Jogos favoritos</h3>
      <ul class="chips">${dados.jogos.map((j, i) => `<li class="chip chip--rosa" style="--i:${i}">${j}</li>`).join('')}</ul>
      <h3 class="app__secao">Ferramentas</h3>
      <ul class="chips">${dados.ferramentas.map((j, i) => `<li class="chip${i === dados.ferramentas.length - 1 ? ' chip--suave' : ''}" style="--i:${i}">${j}</li>`).join('')}</ul>`;
    $('#btn-roda', corpo).addEventListener('click', () => abrirRoda(true));
  };

  /* ===== MISSÕES ===== */
  const missoesVistas = new Set();
  RENDER.missoes = (corpo) => {
    const m = dados.missoes;
    corpo.innerHTML = `
      <section class="missao-principal">
        <p class="missao-principal__rotulo">${icone('estrela')}Missão principal</p>
        <h3 class="missao-principal__titulo">${m.principal}</h3>
        <p class="missao-principal__estado">Em andamento</p>
      </section>
      <h3 class="app__secao">Em andamento</h3>
      <ul class="missoes">
        ${m.andamento.map((x, i) => `
          <li class="missao missao--andamento" style="--i:${i}">
            <span class="missao__marca"><i></i></span>
            <div><p class="missao__titulo">${x.titulo}</p>${x.nota ? `<p class="missao__nota">${x.nota}</p>` : ''}
            <span class="missao__trilha" aria-hidden="true"></span></div>
          </li>`).join('')}
      </ul>
      <h3 class="app__secao">Concluídas <span class="app__contagem">${m.concluidas.length}/${m.concluidas.length}</span></h3>
      <ul class="missoes">
        ${m.concluidas.map((t, i) => `
          <li style="--i:${i}"><button class="missao missao--ok" type="button" data-i="${i}" data-titulo="${t}">
            <span class="missao__marca">${icone('check')}</span>
            <div><p class="missao__titulo">${t}</p><p class="missao__resgate">Toque para resgatar</p></div>
            <span class="missao__selo" aria-hidden="true">CUMPRIDA</span>
          </button></li>`).join('')}
      </ul>`;
    $$('.missao--ok', corpo).forEach((b) => b.addEventListener('click', () => {
      const primeira = !missoesVistas.has(b.dataset.i);
      missoesVistas.add(b.dataset.i);
      b.classList.add('resgatada');
      mostrarBanner(b.dataset.titulo, primeira);
    }));
  };

  /* Banner clássico "MISSÃO CUMPRIDA" */
  let temporizadorBanner;
  function mostrarBanner(titulo, primeira) {
    const el = $('#banner');
    $('#banner-missao').textContent = titulo;
    $('#banner-valor').textContent = primeira ? '+ RESPEITO' : 'JÁ CONCLUÍDA';
    el.hidden = true; void el.offsetWidth; el.hidden = false;      // reinicia as animações
    PA7.som.fanfarra();
    if (primeira) PA7.hud.dinheiro.somar(1500, { som: false });
    clearTimeout(temporizadorBanner);
    temporizadorBanner = setTimeout(() => { el.hidden = true; }, 4500);
  }

  /* ===== CONQUISTAS ===== */
  function desenharConquistas() {
    const corpo = $('#app-conquistas .app__corpo');
    const secretas = dados.conquistasSecretas;
    const abertas = dados.conquistas.length + secretas.filter((s) => PA7.procurado.achou(s.id)).length;
    const total = dados.conquistas.length + secretas.length;
    const pct = Math.round((abertas / total) * 100);
    const C = 2 * Math.PI * 30;
    const card = (c, i, secreta) => {
      const aberta = !secreta || PA7.procurado.achou(c.id);
      const nivel = secreta ? 'secreta' : c.nivel;
      return `<li class="trofeu trofeu--${nivel}${aberta ? '' : ' trofeu--trancado'}" style="--i:${i}">
        <span class="trofeu__icone">${icone(aberta ? c.icone : 'cadeadoFechado')}</span>
        <div><p class="trofeu__nome">${aberta ? c.nome : '???'}</p><p class="trofeu__desc">${aberta ? c.desc : 'Conquista secreta. Alguém precisa ir procurar.'}</p></div>
        <span class="trofeu__nivel">${aberta ? (secreta ? 'secreta' : c.nivel) : 'bloqueada'}</span></li>`;
    };
    corpo.innerHTML = `
      <section class="trofeus-resumo">
        <svg viewBox="0 0 72 72" class="anel" aria-hidden="true" focusable="false"><circle cx="36" cy="36" r="30" class="anel__fundo"/><circle cx="36" cy="36" r="30" class="anel__valor" style="stroke-dasharray:${C};--alvo:${C * (1 - pct / 100)}"/></svg>
        <div><p class="trofeus-resumo__num"><b>${abertas}</b>/${total}</p><p class="trofeus-resumo__txt">troféus desbloqueados · ${pct}%</p></div>
      </section>
      <h3 class="app__secao">Troféus</h3>
      <ul class="trofeus">${dados.conquistas.map((c, i) => card(c, i, false)).join('')}</ul>
      <h3 class="app__secao">Secretas</h3>
      <ul class="trofeus">${secretas.map((c, i) => card(c, i + dados.conquistas.length, true)).join('')}</ul>`;
  }
  RENDER.conquistas = () => desenharConquistas();
  ABRIR.conquistas = () => desenharConquistas();
  document.addEventListener('pa7:segredos', desenharConquistas);

  /* ===== FEED (rede social do jogo) ===== */
  const POSTS = [
    { t: 'agora', txt: 'Bug resolvido às 3h da manhã. Não sei como, mas funciona.', l: 128, c: 14 },
    { t: '40 min', txt: 'Café nº 4 do dia. Produtividade: instável.', l: 97, c: 9 },
    { t: '2 h', txt: 'Hoje teve pescaria. Peixe: 0. Paz: 100.', l: 212, c: 21 },
    { t: '5 h', txt: 'Na minha máquina funciona. Na sua, boa sorte.', l: 341, c: 37 },
    { t: 'ontem', txt: 'A lista de ideias cresceu de novo. A agenda continua do mesmo tamanho.', l: 186, c: 19 },
    { t: 'ontem', txt: 'Treino feito, deploy feito, domingo de futebol garantido.', l: 154, c: 11 },
  ];
  RENDER.feed = (corpo) => {
    corpo.innerHTML = `<ul class="feed">${POSTS.map((p, i) => `
      <li class="post" style="--i:${i}">
        <picture><source srcset="assets/avatar-400.webp" type="image/webp"><img class="post__avatar" src="assets/avatar-400.png" alt="" width="40" height="40" decoding="async"></picture>
        <div class="post__corpo">
          <p class="post__autor"><b>${dados.nome}</b><span>@pedroar7hur · ${p.t}</span></p>
          <p class="post__texto">${p.txt}</p>
          <div class="post__acoes">
            <button class="post__curtir" type="button" aria-pressed="false" aria-label="Curtir" data-n="${p.l}">${icone('coracao')}<span>${p.l}</span></button>
            <span class="post__info">${icone('comentario')}${p.c}</span>
            <span class="post__info">${icone('compartilhar')}</span>
          </div>
        </div>
      </li>`).join('')}</ul>`;
    $$('.post__curtir', corpo).forEach((b) => b.addEventListener('click', () => {
      const on = b.getAttribute('aria-pressed') !== 'true';
      b.setAttribute('aria-pressed', on);
      $('span', b).textContent = +b.dataset.n + (on ? 1 : 0);
    }));
  };

  /* ===== RÁDIO ===== */
  RENDER.radio = (corpo) => PA7.radio.montarApp(corpo);

  /* ===== GITHUB ===== */
  RENDER.github = (corpo) => {
    corpo.innerHTML = `
      <section class="gh">
        <div class="gh__cartao">
          <picture>
            <source srcset="assets/avatar-400.webp" type="image/webp">
            <img class="gh__avatar" src="assets/avatar-400.png" alt="" width="96" height="96" decoding="async">
          </picture>
          <div><p class="gh__nome">${dados.nome}</p><p class="gh__user">@pedroar7hur</p></div>
        </div>
        <pre class="gh__codigo" aria-label="Trecho de código ilustrativo"><code><span class="k">const</span> <span class="v">pedro</span> = {
  <span class="p">nome</span>: <span class="s">'${dados.nome}'</span>,
  <span class="p">classe</span>: <span class="s">'ADS · Criador de sistemas'</span>,
  <span class="p">cafe</span>: <span class="n">Infinity</span>,
  <span class="p">funcionaNaMinhaMaquina</span>: <span class="k">true</span>,
};</code></pre>
        <a class="botao botao--principal gh__link" href="${dados.github}" target="_blank" rel="noopener noreferrer">${icone('github')}Abrir no GitHub${icone('externo')}</a>
        <p class="gh__url">${dados.github.replace('https://', '')}</p>
      </section>`;
  };

  /* ------------------------------------------------------------------
     RODA RADIAL DO INVENTÁRIO (segurar TAB, como a roda de armas)
     ------------------------------------------------------------------ */
  const elRoda = $('#roda');
  let rodaAberta = false, rodaFixa = false, rodaSel = -1;

  function montarRoda() {
    const itens = dados.inventario, n = itens.length, R1 = 96, R2 = 222, folga = 1.8;
    const ponto = (r, a) => [Math.cos(a) * r, Math.sin(a) * r];
    const setor = (i) => {
      const a0 = ((i * 360) / n - 90 - 180 / n + folga) * Math.PI / 180;
      const a1 = (((i + 1) * 360) / n - 90 - 180 / n - folga) * Math.PI / 180;
      const [x0, y0] = ponto(R2, a0), [x1, y1] = ponto(R2, a1), [x2, y2] = ponto(R1, a1), [x3, y3] = ponto(R1, a0);
      return `M${x0.toFixed(1)} ${y0.toFixed(1)}A${R2} ${R2} 0 0 1 ${x1.toFixed(1)} ${y1.toFixed(1)}L${x2.toFixed(1)} ${y2.toFixed(1)}A${R1} ${R1} 0 0 0 ${x3.toFixed(1)} ${y3.toFixed(1)}Z`;
    };
    elRoda.innerHTML = `
      <div class="roda__caixa" role="listbox" aria-label="Roda de itens">
        <svg class="roda__svg" viewBox="-250 -250 500 500" aria-hidden="true" focusable="false">
          <circle r="${R2 + 14}" class="roda__aro"/>
          ${itens.map((_, i) => `<path class="roda__setor" data-i="${i}" d="${setor(i)}"/>`).join('')}
        </svg>
        ${itens.map((it, i) => {
          const a = ((i * 360) / n - 90) * Math.PI / 180, [x, y] = ponto(159, a);
          return `<button type="button" class="roda__item" role="option" data-i="${i}" aria-label="${it.nome}" style="left:${((250 + x) / 5).toFixed(2)}%;top:${((250 + y) / 5).toFixed(2)}%">${icone(it.icone)}</button>`;
        }).join('')}
        <div class="roda__centro" aria-live="polite"><p class="roda__nome">Inventário</p><p class="roda__frase">Passe o mouse em um item</p></div>
      </div>
      <p class="roda__ajuda">Solte <kbd>Tab</kbd> para escolher · <kbd>←</kbd><kbd>→</kbd> navegam · <kbd>Esc</kbd> fecha</p>`;
    const caixa = $('.roda__caixa', elRoda);
    caixa.addEventListener('pointermove', (e) => {
      const r = caixa.getBoundingClientRect();
      const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
      if (Math.hypot(dx, dy) < r.width * 0.17) return;
      let ang = (Math.atan2(dy, dx) * 180) / Math.PI + 90;       // 0° = topo
      ang = (ang + 360 + 180 / n) % 360;
      selecionarRoda(Math.floor(ang / (360 / n)) % n);
    });
    elRoda.addEventListener('click', (e) => {
      const alvo = e.target.closest('.roda__item, .roda__setor');
      if (alvo) { selecionarRoda(+alvo.dataset.i); fecharRoda(true); } else if (!e.target.closest('.roda__caixa')) fecharRoda(false);
    });
  }
  function selecionarRoda(i) {
    if (i === rodaSel) return;
    rodaSel = i;
    const it = dados.inventario[i];
    $$('.roda__setor, .roda__item', elRoda).forEach((el) => el.classList.toggle('ativo', +el.dataset.i === i));
    $('.roda__nome', elRoda).textContent = it.nome + (it.detalhe ? ` (${it.detalhe})` : '');
    $('.roda__frase', elRoda).textContent = it.frase;
    PA7.som.tick();
  }
  function abrirRoda(fixa) {
    if (rodaAberta || PA7.ehCelular()) return;
    rodaAberta = true; rodaFixa = !!fixa; rodaSel = -1;
    if (!elRoda.firstChild) montarRoda();
    elRoda.hidden = false; elRoda.setAttribute('aria-hidden', 'false');
    $('.roda__nome', elRoda).textContent = 'Inventário';
    $('.roda__frase', elRoda).textContent = 'Passe o mouse em um item';
    $$('.ativo', elRoda).forEach((e) => e.classList.remove('ativo'));
    elRoda.classList.remove('fechando'); void elRoda.offsetWidth; elRoda.classList.add('aberta');
    PA7.som.abrir();
  }
  /* `confirmar` = escolheu um item (mostra notificação "Item equipado"). */
  function fecharRoda(confirmar) {
    if (!rodaAberta) return;
    rodaAberta = false; rodaFixa = false;
    elRoda.classList.remove('aberta');
    elRoda.hidden = true; elRoda.setAttribute('aria-hidden', 'true');
    if (confirmar !== false && rodaSel >= 0) {
      const it = dados.inventario[rodaSel];
      PA7.hud.notificar({ titulo: 'Item equipado: ' + it.nome, texto: it.frase, tipo: 'rosa', icone: it.icone });
    }
  }

  /* Tab segurado abre a roda (apenas desktop, com o app Inventário aberto). */
  document.addEventListener('keydown', (e) => {
    if (appAtual !== 'inventario' || PA7.ehCelular()) return;
    if (document.body.classList.contains('terminal-aberto') || document.body.classList.contains('modal-aberto')) return;
    if (e.key === 'Tab') {
      // Se o foco já está num controle do app, deixa o Tab navegar normalmente (acessibilidade).
      if (e.shiftKey || document.activeElement.closest('.app__corpo, .app__voltar')) return;
      e.preventDefault();
      abrirRoda(false);
    } else if (rodaAberta && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')) {
      e.preventDefault();
      const n = dados.inventario.length;
      selecionarRoda(((rodaSel < 0 ? 0 : rodaSel) + (e.key === 'ArrowRight' ? 1 : -1) + n) % n);
    }
  });
  document.addEventListener('keyup', (e) => { if (e.key === 'Tab' && rodaAberta && !rodaFixa) fecharRoda(true); });
  window.addEventListener('blur', () => { if (rodaAberta && !rodaFixa) fecharRoda(false); });

  /* ------------------------------------------------------------------
     API pública
     ------------------------------------------------------------------ */
  PA7.celular = {
    apps: APPS,
    abrir, voltar, guardar, mostrar,
    get appAtual() { return appAtual; },
    get guardado() { return elCelular.classList.contains('guardado'); },
    get rodaAberta() { return rodaAberta; },
    fecharRoda,
    iniciar() {
      montarGrade(); montarApps();
      atualizarRelogio(); setInterval(atualizarRelogio, 10000);
      $('#btn-home').addEventListener('click', () => { if (!voltar()) { PA7.som.tick(); } });
      $('#btn-guardar').addEventListener('click', guardar);
      $('#btn-celular-hud').addEventListener('click', mostrar);
    },
  };
})();
