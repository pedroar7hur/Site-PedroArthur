/* ==========================================================================
   terminal.js — Terminal "hacker" do PedroAr7hur.
   - Comandos públicos (aparecem no `help`)
   - 5 easter eggs escondidos (cada um dá +1 estrela de procurado)
   - Histórico com ↑/↓, autocompletar com Tab, saída com efeito de digitação
   O efeito de digitação pode ser pulado (Enter, clique ou comando `skip`).
   ========================================================================== */
(function () {
  const $ = PA7.$;
  const raiz = $('#terminal');
  const corpo = $('#terminal-corpo');
  const form = $('#terminal-form');
  const entrada = $('#terminal-input');

  /* Região "aria-live" invisível: leitores de tela ouvem cada linha PRONTA,
     em vez de letra por letra (a digitação visual não vai para o leitor). */
  const anuncio = document.createElement('div');
  anuncio.className = 'so-leitor';
  anuncio.setAttribute('aria-live', 'polite');
  raiz.appendChild(anuncio);

  /* ----- Estado ----- */
  let aberto = false;
  let ocupado = false;            // true enquanto uma saída está sendo "digitada"
  let pular = false;              // pedido de pular a digitação atual
  let boasVindasFeitas = false;
  let historico = [];
  let posHistorico = 0;
  let rascunho = '';
  let focoAnterior = null;
  const pendentes = new Set();    // esperas em andamento (para poder pulá-las)

  /* Velocidade da digitação em caracteres por segundo */
  const VELOCIDADES = { lenta: 80, normal: 240, rapida: 900, instantanea: Infinity };
  let velocidade = 'normal';
  const cps = () => (PA7.reduzMovimento.matches ? Infinity : VELOCIDADES[velocidade]);

  /* ------------------------------------------------------------------
     Primitivas de saída
     ------------------------------------------------------------------ */
  const rolar = () => { corpo.scrollTop = corpo.scrollHeight; };

  /* Espera `ms`, mas termina na hora se o usuário pedir para pular. */
  function espera(ms) {
    if (pular) return Promise.resolve();
    return new Promise((ok) => {
      const fim = () => { clearTimeout(t); pendentes.delete(fim); ok(); };
      const t = setTimeout(fim, ms);
      pendentes.add(fim);
    });
  }
  function pularDigitacao() {
    pular = true;
    Array.from(pendentes).forEach((f) => f());
  }
  const quadro = () => new Promise((ok) => requestAnimationFrame(ok));

  /* Digita `texto` dentro de `el`, respeitando a velocidade. */
  async function digitar(el, texto, velocidadeLinha) {
    const letras = Array.from(texto);                  // Array.from: não quebra emojis ao meio
    const v = velocidadeLinha || cps();
    if (pular || v === Infinity) { el.textContent = texto; return; }
    const t0 = performance.now();
    let n = 0;
    while (n < letras.length && !pular) {
      await quadro();
      n = Math.min(letras.length, Math.floor(((performance.now() - t0) / 1000) * v));
      el.textContent = letras.slice(0, n).join('');
      rolar();
    }
    el.textContent = texto;
  }

  /* Cria uma linha. `item` pode ser string, ou objeto:
     { partes:[{t, c}], cls, cps, depois(ms de pausa), instantaneo } */
  const L = (t, c, extra) => Object.assign({ partes: [{ t, c }] }, extra);
  const M = (...partes) => ({ partes: partes.map(([t, c]) => ({ t, c })) });

  async function escrever(item) {
    if (typeof item === 'string') item = L(item);
    const div = document.createElement('div');
    div.className = 't-linha' + (item.cls ? ' ' + item.cls : '');
    corpo.appendChild(div);
    let completo = '';
    for (const p of item.partes) {
      const span = document.createElement('span');
      if (p.c) span.className = p.c;
      div.appendChild(span);
      if (item.instantaneo) span.textContent = p.t; else await digitar(span, p.t, item.cps);
      completo += p.t;
    }
    if (!completo) div.innerHTML = '&nbsp;';
    anuncio.textContent = completo;
    rolar();
    if (item.depois) await espera(item.depois);
    return div;
  }
  async function bloco(lista) { for (const item of lista) await escrever(item); }

  /* Linha de eco do comando digitado (com o prompt colorido) */
  function ecoComando(texto) {
    const div = document.createElement('div');
    div.className = 't-linha t-eco';
    div.innerHTML = '<span class="t-usuario">pedroar7hur@vicecity</span><span class="t-sep">:</span><span class="t-caminho">~</span><span class="t-cifrao">$</span> ';
    const s = document.createElement('span'); s.textContent = texto; div.appendChild(s);
    corpo.appendChild(div); rolar();
  }

  /* ------------------------------------------------------------------
     Utilitários de formatação
     ------------------------------------------------------------------ */
  const barraAscii = (v) => { const f = Math.floor(v / 10); return '[' + '█'.repeat(f) + '░'.repeat(10 - f) + ']'; };
  const dados = PA7.dados;
  const registrar = (id) => PA7.procurado.encontrar(id);

  /* ------------------------------------------------------------------
     COMANDOS PÚBLICOS
     ------------------------------------------------------------------ */
  const publicos = {
    help: { desc: 'lista os comandos', fn: async () => {
      await bloco([L('Comandos disponíveis:', 't-ciano')]);
      const linhas = Object.entries(publicos).map(([nome, c]) => M(['  ' + nome.padEnd(13), 't-rosa'], [c.desc, '']));
      await bloco(linhas);
      await bloco([L('Dica: use Tab para completar e ↑ ↓ para o histórico.', 't-suave')]);
    } },
    whoami: { desc: 'quem é essa pessoa', fn: () => bloco([
      M(['Nome      ', 't-suave'], [dados.nome, '']),
      M(['Nickname  ', 't-suave'], [dados.nickname, 't-rosa']),
      M(['Classe    ', 't-suave'], [dados.classe, '']),
      M(['Status    ', 't-suave'], [dados.status, 't-ok']),
    ]) },
    bio: { desc: 'a bio principal', fn: () => bloco([L('“' + dados.bio + '”', 't-amarelo')]) },
    stats: { desc: 'atributos do personagem', fn: () => bloco(
      dados.atributos.map((a) => M([barraAscii(a.valor) + ' ', 't-ciano'], [String(a.valor).padStart(3) + '  ', 't-ok'], [a.nome, a.transborda ? 't-amarelo' : ''])),
    ) },
    skills: { desc: 'habilidades desbloqueadas', fn: async () => {
      await bloco([L('Técnicas:', 't-ciano'), L('  ' + dados.habilidades.tecnicas.map((s) => s.nome).join(' · '))]);
      await bloco([L('Mentais:', 't-ciano'), L('  ' + dados.habilidades.mentais.map((s) => s.nome).join(' · '))]);
    } },
    inventario: { desc: 'o que o Pedro curte', fn: () => bloco(
      dados.inventario.map((i) => M(['  ▸ ', 't-rosa'], [i.nome + (i.detalhe ? ' (' + i.detalhe + ')' : ''), ''])),
    ) },
    jogos: { desc: 'jogos favoritos', fn: () => bloco([L(dados.jogos.join(' · '), 't-amarelo')]) },
    ferramentas: { desc: 'ferramentas do dia a dia', fn: () => bloco([L(dados.ferramentas.join(' · '), 't-ciano')]) },
    missoes: { desc: 'missões do jogo', fn: async () => {
      await bloco(dados.missoes.concluidas.map((m) => M(['✔ ', 't-ok'], [m, ''])));
      await bloco(dados.missoes.andamento.map((m) => M(['⏳ ', 't-amarelo'], [m.titulo, ''])));
      await bloco([M(['★ Missão principal: ', 't-rosa'], [dados.missoes.principal, 't-amarelo'])]);
    } },
    conquistas: { desc: 'troféus (e os secretos)', fn: async () => {
      await bloco(dados.conquistas.map((c) => M(['◆ ', 't-amarelo'], [c.nome, 't-ok'], [' — ' + c.desc, 't-suave'])));
      await bloco(dados.conquistasSecretas.map((c) => PA7.procurado.achou(c.id)
        ? M(['◆ ', 't-rosa'], [c.nome, 't-rosa'], [' — ' + c.desc, 't-suave'])
        : M(['◇ ', 't-suave'], ['???', 't-suave'], [' — conquista secreta', 't-suave'])));
    } },
    github: { desc: 'abre o GitHub', fn: async () => {
      await bloco([L('Abrindo ' + dados.github + ' em nova aba...', 't-ciano')]);
      const div = await escrever(L('', '', { instantaneo: true }));
      div.innerHTML = `<a class="t-link" href="${dados.github}" target="_blank" rel="noopener noreferrer">${dados.github}</a>`;
      // Alguns navegadores bloqueiam janelas abertas por código; o link acima é o plano B.
      window.open(dados.github, '_blank', 'noopener,noreferrer');
    } },
    estrelas: { desc: 'nível de procurado', fn: async () => {
      const n = PA7.procurado.estrelas;
      await bloco([M(['Nível de procurado: ', ''], ['★'.repeat(n) + '☆'.repeat(5 - n), n ? 't-amarelo' : 't-suave'], [`  (${n}/5)`, 't-suave'])]);
      if (n >= 5) await bloco([L('Nível máximo. Você é o mais procurado de Vice City.', 't-rosa')]);
      else await bloco([L(`Segredos restantes: ${PA7.procurado.faltam}. Boa caçada.`, 't-suave')]);
    } },
    skip: { desc: 'pula a digitação', fn: async () => {} },
    velocidade: { desc: 'lenta | normal | rapida', fn: async (arg) => {
      const nome = (arg || '').normalize('NFD').replace(/[̀-ͯ]/g, '');
      if (VELOCIDADES[nome]) { velocidade = nome; await bloco([L('Velocidade da digitação: ' + nome + '.', 't-ok')]); }
      else await bloco([L('Velocidade atual: ' + velocidade + '. Use: velocidade lenta | normal | rapida', 't-suave')]);
    } },
    clear: { desc: 'limpa a tela', fn: async () => { corpo.innerHTML = ''; } },
    exit: { desc: 'fecha o terminal', fn: async () => { await espera(150); fechar(); } },
  };

  /* ------------------------------------------------------------------
     EASTER EGGS (não aparecem no help)
     ------------------------------------------------------------------ */
  const segredos = {
    /* 1) sudo ideia */
    async ideiaSecreta() {
      const lento = 42;   // pausas dramáticas: digita devagar
      await escrever(L('> Ideia detectada...', 't-ciano', { cps: lento, depois: 800 }));
      await escrever(L('> Projeto iniciado.', 't-ok', { cps: lento, depois: 900 }));
      await escrever(L('> Dinheiro ainda não encontrado. 😂', 't-amarelo', { cps: lento, depois: 700 }));
      await escrever('');
      await escrever(L('[STATUS] Trabalhando em novas oportunidades...', 't-rosa', { cps: 70 }));
      await PA7.hud.dinheiro.piada();
      registrar('ovo-ideia');
    },

    /* 2) npm run deploy */
    async deploy() {
      await bloco([L('> pedroar7hur@1.0.0 deploy', 't-suave'), L('> build && publish --prod', 't-suave'), L('Enviando para produção...', 't-ciano')]);
      const barra = await escrever(L('', 't-amarelo', { instantaneo: true }));
      const total = 22;
      for (let p = 0; p <= 99; p += 1 + Math.floor(Math.random() * 6)) {
        const f = Math.floor((p / 100) * total);
        barra.textContent = `[${'█'.repeat(f)}${'░'.repeat(total - f)}] ${p}%`;
        rolar();
        await espera(40 + Math.random() * 60);
        if (pular) break;
      }
      barra.textContent = `[${'█'.repeat(total - 1)}░] 99%`;
      barra.classList.add('t-travado');
      await espera(1500);
      PA7.som.erro();
      await escrever(L('ERRO: ambiente de produção diferente do local.', 't-erro', { cps: 120, depois: 500 }));
      const grande = await escrever(L('"Na minha máquina funciona!" ✅', 't-grande t-ok', { instantaneo: true }));
      grande.classList.add('t-piscando');
      registrar('ovo-deploy');
    },

    /* 3) ideias: a lista não para de crescer */
    async ideias() {
      await escrever(L('> Listando projetos em andamento...', 't-ciano', { depois: 300 }));
      for (let n = 1; n <= 47; n++) {
        await escrever(L(`Ideia #${n}... em andamento`, n % 5 === 0 ? 't-amarelo' : '', { instantaneo: true }));
        PA7.som.teclar();
        await espera(Math.max(14, 300 * Math.pow(0.86, n)));    // acelera a cada ideia
      }
      await escrever(L('[AVISO] Agenda cheia. Lista de ideias: ainda crescendo.', 't-erro t-piscando', { depois: 400 }));
      for (let n = 48; n <= 51; n++) await escrever(L(`Ideia #${n}...`, 't-suave', { instantaneo: true, depois: 140 }));
      registrar('ovo-ideias');
    },

    /* 4) cafe: a barra vai de 97 para 100 */
    async cafe() {
      const atributo = dados.atributos.find((a) => a.id === 'cafe');
      await escrever(L('Injetando cafeína no sistema...', 't-ciano', { depois: 300 }));
      const linha = await escrever(L('', 't-ok', { instantaneo: true }));
      for (let v = Math.min(atributo.valor, 97); v <= 100; v++) {
        linha.textContent = `Café no Sangue ${barraAscii(v)} ${v}`;
        PA7.som.teclar();
        await espera(260);
      }
      atributo.valor = 100;                                      // a barra do app Ficha passa a mostrar 100
      await escrever(L('☕ Recarregado. Produtividade +∞.', 't-amarelo', { depois: 200 }));
      registrar('ovo-cafe');
    },

    /* 5) sudo rm -rf / : a polícia chega */
    async apagar() {
      await escrever(L('Removendo / ...', 't-suave', { cps: 300, depois: 400 }));
      const flash = $('#flash-policia');
      document.body.classList.add('tremer');
      flash.classList.remove('ativo'); void flash.offsetWidth; flash.classList.add('ativo');
      PA7.som.sirene();
      await escrever(L('ACESSO NEGADO. Polícia a caminho.', 't-erro t-grande t-piscando', { instantaneo: true }));
      registrar('ovo-rm');
      await espera(2500);
      document.body.classList.remove('tremer'); flash.classList.remove('ativo');
      await escrever(L('(Calma, era brincadeira. Nada foi apagado.)', 't-suave'));
    },
  };

  /* Reconhece os comandos secretos, aceitando pequenas variações. */
  function achaSegredo(c) {
    if (c === 'sudo ideia') return segredos.ideiaSecreta;
    if (c === 'npm run deploy' || c === 'deploy') return segredos.deploy;
    if (c === 'ideias') return segredos.ideias;
    if (c === 'cafe' || c === 'café') return segredos.cafe;
    if (/^sudo rm -rf( --no-preserve-root)?( \/\*?)?$/.test(c)) return segredos.apagar;
    return null;
  }

  /* ------------------------------------------------------------------
     Execução de um comando
     ------------------------------------------------------------------ */
  async function executar(texto) {
    const limpo = texto.trim().replace(/\s+/g, ' ');
    ecoComando(texto);
    if (!limpo) return;
    historico.push(limpo);
    const comando = limpo.toLowerCase();
    const [nome, ...resto] = comando.split(' ');

    ocupado = true; pular = false;
    entrada.readOnly = true; form.classList.add('ocupado');
    try {
      const segredo = achaSegredo(comando);
      if (segredo) await segredo();
      else if (nome === 'ajuda') await publicos.help.fn();
      else if (nome === 'inventário') await publicos.inventario.fn();
      else if (nome === 'sudo') await bloco([L('Você não está no arquivo sudoers. Este incidente será reportado. (ou não)', 't-erro')]);
      else if (publicos[nome]) await publicos[nome].fn(resto.join(' '));
      else {
        PA7.som.erro();
        await bloco([L(`comando não encontrado: ${limpo}. Tente "help". (ou funciona só na minha máquina)`, 't-erro')]);
      }
    } finally {
      ocupado = false; pular = false;
      entrada.readOnly = false; form.classList.remove('ocupado');
      if (aberto) entrada.focus({ preventScroll: true });
      rolar();
    }
  }

  /* ------------------------------------------------------------------
     Autocompletar (Tab) e histórico (↑/↓)
     ------------------------------------------------------------------ */
  function autocompletar() {
    const atual = entrada.value.toLowerCase().trimStart();
    if (!atual || atual.includes(' ')) return;
    const opcoes = Object.keys(publicos).filter((n) => n.startsWith(atual));
    if (opcoes.length === 1) { entrada.value = opcoes[0] + ' '; return; }
    if (opcoes.length > 1) {
      // completa o prefixo comum e lista as opções
      let comum = opcoes[0];
      opcoes.forEach((o) => { while (!o.startsWith(comum)) comum = comum.slice(0, -1); });
      entrada.value = comum;
      ecoComando(entrada.value);
      const div = document.createElement('div'); div.className = 't-linha t-suave'; div.textContent = opcoes.join('   ');
      corpo.appendChild(div); rolar();
    }
  }

  entrada.addEventListener('keydown', (e) => {
    if (ocupado) {                              // durante a digitação, Enter (ou qualquer tecla) pula
      if (e.key === 'Enter') { e.preventDefault(); pularDigitacao(); }
      return;
    }
    if (e.key === 'Tab') { e.preventDefault(); autocompletar(); }
    else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (posHistorico === historico.length) rascunho = entrada.value;
      if (posHistorico > 0) entrada.value = historico[--posHistorico];
      entrada.setSelectionRange(entrada.value.length, entrada.value.length);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (posHistorico < historico.length) { posHistorico++; entrada.value = posHistorico === historico.length ? rascunho : historico[posHistorico]; }
    } else if (e.key === 'l' && e.ctrlKey) { e.preventDefault(); corpo.innerHTML = ''; }
    else if (e.key.length === 1) PA7.som.teclar();
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (ocupado) { pularDigitacao(); return; }
    const texto = entrada.value;
    entrada.value = '';
    await executar(texto);
    posHistorico = historico.length; rascunho = '';
  });

  // Clicar na área de saída: pula a digitação ou foca o campo
  corpo.addEventListener('click', () => {
    if (window.getSelection().toString()) return;            // não atrapalha quem está selecionando texto
    if (ocupado) pularDigitacao(); else entrada.focus();
  });

  /* ------------------------------------------------------------------
     Abrir / fechar
     ------------------------------------------------------------------ */
  async function abrir() {
    if (aberto) return;
    aberto = true;
    focoAnterior = document.activeElement;
    raiz.hidden = false;
    document.body.classList.add('terminal-aberto');
    raiz.classList.remove('ligando'); void raiz.offsetWidth; raiz.classList.add('ligando');
    PA7.som.abrir();
    entrada.focus({ preventScroll: true });
    if (!boasVindasFeitas) {
      boasVindasFeitas = true;
      ocupado = true; pular = false; entrada.readOnly = true;
      await bloco([
        L('█▀█ ▄▀█ ▀▀█', 't-rosa t-logo', { instantaneo: true }),
        L('█▀▀ █▀█   █', 't-amarelo t-logo', { instantaneo: true }),
        L('▀   ▀ ▀   ▀', 't-ciano t-logo', { instantaneo: true }),
        '',
        L('Bem-vindo ao sistema de PedroAr7hur. Digite "help" para ver os comandos.', 't-ok'),
      ]);
      ocupado = false; pular = false; entrada.readOnly = false;
      if (aberto) entrada.focus({ preventScroll: true });
    }
  }
  function fechar() {
    if (!aberto) return;
    pularDigitacao();
    aberto = false;
    raiz.hidden = true;
    document.body.classList.remove('terminal-aberto', 'tremer');
    $('#flash-policia').classList.remove('ativo');
    PA7.som.voltar();
    if (focoAnterior && focoAnterior.isConnected && focoAnterior.focus) focoAnterior.focus({ preventScroll: true });
  }

  $('#terminal-fechar').addEventListener('click', fechar);
  // Esc fecha; Tab fica dentro da janela (diálogo modal)
  raiz.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.stopPropagation(); fechar(); }
  });
  raiz.addEventListener('click', (e) => { if (e.target === raiz) fechar(); });

  PA7.terminal = {
    abrir, fechar,
    alternar() { aberto ? fechar() : abrir(); },
    get aberto() { return aberto; },
    get campo() { return entrada; },
  };
})();
