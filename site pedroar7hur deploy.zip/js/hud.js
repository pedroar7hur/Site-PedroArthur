/* ==========================================================================
   hud.js — Elementos fixos da interface de jogo:
   dinheiro, estrelas de procurado, notificações e minimapa.
   ========================================================================== */
(function () {
  const $ = PA7.$;

  /* ------------------------------------------------------------------
     NOTIFICAÇÕES estilo jogo (aparecem no topo e somem sozinhas)
     ------------------------------------------------------------------ */
  const caixaNotif = $('#notificacoes');

  function notificar({ titulo, texto = '', tipo = 'info', icone = 'estrela', duracao = 3800, silencioso = false }) {
    const n = document.createElement('div');
    n.className = 'notif' + (tipo !== 'info' ? ' notif--' + tipo : '');
    n.innerHTML = `<span class="notif__icone">${PA7.icone(icone)}</span>
      <div><p class="notif__titulo"></p><p class="notif__texto"></p></div>`;
    n.querySelector('.notif__titulo').textContent = titulo;      // textContent evita injetar HTML
    n.querySelector('.notif__texto').textContent = texto;
    if (!texto) n.querySelector('.notif__texto').remove();
    caixaNotif.appendChild(n);
    if (!silencioso) PA7.som.notificar();

    // Mantém no máximo 3 na tela
    while (caixaNotif.children.length > 3) caixaNotif.firstElementChild.remove();

    setTimeout(() => {
      n.classList.add('saindo');
      n.addEventListener('animationend', () => n.remove(), { once: true });
      setTimeout(() => n.remove(), 700);   // garantia caso a animação seja desligada
    }, duracao);
  }

  /* ------------------------------------------------------------------
     DINHEIRO: sobe aos poucos, de brincadeira
     ------------------------------------------------------------------ */
  const elDinheiro = $('#hud-dinheiro');
  let dinheiro = 0;          // valor real
  let mostrado = 0;          // valor exibido (anima até o real)
  let modoCheat = false;
  let animacaoId = 0;

  function formatar(v) {
    const s = String(Math.max(0, Math.floor(v))).padStart(7, '0');
    return '$ ' + s[0] + '.' + s.slice(1, 4) + '.' + s.slice(4);
  }
  function desenhar() {
    elDinheiro.textContent = modoCheat ? '$ ∞' : formatar(mostrado);
  }

  /* Anima o número até `alvo` em `dur` ms, com desaceleração (easeOutExpo). */
  function animarPara(alvo, dur = 700) {
    const id = ++animacaoId;
    const inicio = mostrado, t0 = performance.now();
    if (PA7.reduzMovimento.matches || dur <= 0) { mostrado = alvo; desenhar(); return Promise.resolve(); }
    return new Promise((ok) => {
      (function passo(agora) {
        if (id !== animacaoId) return ok();           // outra animação assumiu
        const t = Math.min(1, (agora - t0) / dur);
        const e = t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
        mostrado = inicio + (alvo - inicio) * e;
        desenhar();
        if (t < 1) requestAnimationFrame(passo); else ok();
      })(t0);
    });
  }
  function pulsar(classe) {
    elDinheiro.classList.remove('sobe', 'cai');
    void elDinheiro.offsetWidth;                      // reinicia a animação CSS
    elDinheiro.classList.add(classe);
  }

  const dinheiroAPI = {
    somar(qtd, { som = false } = {}) {
      if (modoCheat) return;
      dinheiro = Math.min(9999999, dinheiro + qtd);
      animarPara(dinheiro, 600); pulsar('sobe');
      if (som) PA7.som.dinheiro();
    },
    /* Easter egg "sudo ideia": o dinheiro sobe e despenca para zero. */
    async piada() {
      if (modoCheat) return;
      dinheiro += 18500; pulsar('sobe'); PA7.som.dinheiro();
      await animarPara(dinheiro, 1500);
      await PA7.espera(500);
      dinheiro = 0; mostrado = 0; animacaoId++; desenhar(); pulsar('cai'); PA7.som.erro();
    },
    /* Konami: dinheiro infinito. */
    cheat() {
      modoCheat = true; animacaoId++;
      elDinheiro.classList.add('cheat'); desenhar(); pulsar('sobe');
    },
    get cheat_ativo() { return modoCheat; },
  };

  /* Crescimento passivo: alguns trocados a cada ~2s (só enquanto a aba está visível). */
  function iniciarRenda() {
    setInterval(() => {
      if (document.hidden || modoCheat) return;
      dinheiroAPI.somar(Math.floor(3 + Math.random() * 34));
    }, 2000);
  }

  /* ------------------------------------------------------------------
     ESTRELAS DE PROCURADO
     ------------------------------------------------------------------ */
  const elEstrelas = $('#hud-estrelas');
  function montarEstrelas() {
    elEstrelas.innerHTML = '';
    for (let i = 0; i < 5; i++) {
      const s = document.createElement('span');
      s.className = 'estrela-hud';
      s.innerHTML = PA7.icone('estrela');
      elEstrelas.appendChild(s);
    }
  }
  function definirEstrelas(n, animarNova = false) {
    const lista = elEstrelas.children;
    for (let i = 0; i < lista.length; i++) {
      const ligar = i < n;
      const estava = lista[i].classList.contains('ligada');
      lista[i].classList.toggle('ligada', ligar);
      if (ligar && !estava && animarNova) {
        lista[i].classList.remove('nova'); void lista[i].offsetWidth; lista[i].classList.add('nova');
      }
    }
    elEstrelas.setAttribute('aria-label', `Nível de procurado: ${n} de 5 estrelas`);
  }
  /* Pisca vermelho/azul por alguns segundos depois de ganhar estrela. */
  function alertaEstrelas() {
    elEstrelas.classList.add('alerta');
    clearTimeout(alertaEstrelas.t);
    alertaEstrelas.t = setTimeout(() => elEstrelas.classList.remove('alerta'), 5000);
  }

  /* ------------------------------------------------------------------
     MINIMAPA: cada "blip" é uma seção clicável
     ------------------------------------------------------------------ */
  // Posições em coordenadas polares (ângulo em graus, distância do centro em %)
  const POSICOES = [[-60, 58], [-15, 66], [30, 52], [72, 70], [118, 56], [160, 68], [205, 52], [250, 66], [95, 30]];
  const CORES = ['#ff4f9a', '#ffb347', '#ffb347', '#6fdc8c', '#ff8f6b', '#8a5cf6', '#ff4f9a', '#ffb347'];

  function montarMinimapa(apps, abrir) {
    const caixa = $('#minimapa-blips');
    const legenda = $('#minimapa-legenda');
    apps.forEach((app, i) => {
      const [ang, dist] = POSICOES[i % POSICOES.length];
      const rad = (ang * Math.PI) / 180;
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'minimapa__blip';
      b.style.cssText = `left:${50 + Math.cos(rad) * dist * 0.5}%;top:${50 + Math.sin(rad) * dist * 0.5}%;--atraso:${i * 0.3}s`;
      b.innerHTML = PA7.icone(app.icone);
      b.setAttribute('aria-label', 'Ir para ' + app.nome);
      const falar = () => { legenda.textContent = app.nome; };
      const limpar = () => { legenda.textContent = 'Você está aqui'; };
      b.addEventListener('mouseenter', () => { falar(); PA7.som.tick(); });
      b.addEventListener('focus', falar);
      b.addEventListener('mouseleave', limpar);
      b.addEventListener('blur', limpar);
      b.addEventListener('click', () => abrir(app.id));
      caixa.appendChild(b);
    });
  }

  PA7.hud = {
    notificar,
    dinheiro: dinheiroAPI,
    estrelas: { definir: definirEstrelas, alerta: alertaEstrelas },
    montarMinimapa,
    iniciar() { montarEstrelas(); desenhar(); iniciarRenda(); },
  };
})();
