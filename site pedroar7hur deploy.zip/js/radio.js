/* ==========================================================================
   radio.js — Rádio "PA7 FM: a rádio de quem constrói".
   A música é GERADA em tempo real com a Web Audio API (nenhum MP3):
   bateria (bumbo, caixa, chimbal) + baixo serrilhado + pad de acordes
   + arpejo com eco, tudo num loop de 4 compassos (Am – F – C – G, ~104 BPM).
   Um AnalyserNode alimenta o visualizador de barras.
   ========================================================================== */
(function () {
  const BPM = 104;
  const PASSO = 60 / BPM / 4;               // duração de uma semicolcheia (1/16), em segundos
  const hz = (midi) => 440 * Math.pow(2, (midi - 69) / 12);

  /* Progressão do loop: nota do baixo e notas do acorde (números MIDI) por compasso. */
  const COMPASSOS = [
    { baixo: 45, acorde: [57, 60, 64] },    // Lá menor
    { baixo: 41, acorde: [53, 57, 60] },    // Fá maior
    { baixo: 48, acorde: [55, 60, 64] },    // Dó maior
    { baixo: 43, acorde: [55, 59, 62] },    // Sol maior
  ];

  let ctx = null, barramento = null, analisador = null, volume = null, eco = null;
  let tocando = false, passoAtual = 0, proxTempo = 0, relogio = null;
  let volumePct = PA7.guardar.ler('radioVolume', 60);
  const ouvintes = new Set();               // quem quer saber quando liga/desliga

  /* ----- Monta a "mesa de som" uma única vez ----- */
  function montar() {
    ctx = PA7.som.contexto();
    if (!ctx || barramento) return !!ctx;
    barramento = ctx.createGain(); barramento.gain.value = 0.9;
    const compressor = ctx.createDynamicsCompressor();
    compressor.threshold.value = -16; compressor.ratio.value = 5;
    analisador = ctx.createAnalyser(); analisador.fftSize = 128; analisador.smoothingTimeConstant = 0.78;
    volume = ctx.createGain(); volume.gain.value = 0;
    barramento.connect(compressor).connect(analisador).connect(volume).connect(ctx.destination);
    // Eco do arpejo: delay com realimentação
    eco = ctx.createDelay(1); eco.delayTime.value = PASSO * 3;
    const fb = ctx.createGain(); fb.gain.value = 0.36;
    const filtroEco = ctx.createBiquadFilter(); filtroEco.type = 'lowpass'; filtroEco.frequency.value = 2600;
    eco.connect(filtroEco).connect(fb).connect(eco);
    filtroEco.connect(barramento);
    return true;
  }

  /* ----- Instrumentos ----- */
  function env(g, t, ataque, pico, dur) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(pico, t + ataque);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  }
  function bumbo(t) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
    env(g, t, 0.004, 0.95, 0.32);
    o.connect(g).connect(barramento); o.start(t); o.stop(t + 0.35);
  }
  function ruidoFiltrado(t, tipo, freq, dur, pico, destino) {
    const s = ctx.createBufferSource(); s.buffer = PA7.som.buffer;
    const f = ctx.createBiquadFilter(); f.type = tipo; f.frequency.value = freq;
    const g = ctx.createGain(); env(g, t, 0.002, pico, dur);
    s.connect(f).connect(g).connect(destino || barramento); s.start(t); s.stop(t + dur + 0.02);
  }
  function caixa(t) {
    ruidoFiltrado(t, 'highpass', 1500, 0.22, 0.55);
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'triangle'; o.frequency.setValueAtTime(220, t); o.frequency.exponentialRampToValueAtTime(120, t + 0.1);
    env(g, t, 0.002, 0.4, 0.14); o.connect(g).connect(barramento); o.start(t); o.stop(t + 0.16);
  }
  function chimbal(t, aberto) { ruidoFiltrado(t, 'highpass', 7500, aberto ? 0.28 : 0.05, aberto ? 0.16 : 0.12); }
  function baixo(t, nota, dur) {
    const o = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    o.type = 'sawtooth'; o.frequency.value = hz(nota);
    f.type = 'lowpass'; f.Q.value = 6;
    f.frequency.setValueAtTime(1400, t); f.frequency.exponentialRampToValueAtTime(260, t + dur);
    env(g, t, 0.005, 0.5, dur);
    o.connect(f).connect(g).connect(barramento); o.start(t); o.stop(t + dur + 0.02);
  }
  function pad(t, notas, dur) {
    notas.forEach((n) => [-7, 7].forEach((cents) => {
      const o = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain();
      o.type = 'sawtooth'; o.frequency.value = hz(n); o.detune.value = cents;
      f.type = 'lowpass'; f.frequency.value = 1100;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.045, t + 0.7);
      g.gain.setValueAtTime(0.045, t + dur - 0.5);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.4);
      o.connect(f).connect(g).connect(barramento); o.start(t); o.stop(t + dur + 0.5);
    }));
  }
  function arpejo(t, nota) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'square'; o.frequency.value = hz(nota);
    env(g, t, 0.004, 0.11, PASSO * 2.2);
    o.connect(g); g.connect(barramento); g.connect(eco); o.start(t); o.stop(t + PASSO * 2.4);
  }

  /* ----- Sequenciador: decide o que tocar em cada "passo" de 1/16 ----- */
  function agendar(passo, t) {
    const noCompasso = passo % 16;
    const c = COMPASSOS[Math.floor(passo / 16) % COMPASSOS.length];
    if ([0, 8, 10].includes(noCompasso)) bumbo(t);
    if ([4, 12].includes(noCompasso)) caixa(t);
    if (noCompasso % 2 === 0) chimbal(t, noCompasso === 14);
    if (noCompasso % 2 === 0) baixo(t, c.baixo + (noCompasso === 6 || noCompasso === 14 ? 12 : 0), PASSO * 1.8);
    if (noCompasso === 0) pad(t, c.acorde, PASSO * 16);
    if (noCompasso % 2 === 0) arpejo(t, c.acorde[(noCompasso / 2) % 3] + 12 + ((noCompasso / 2) % 4 === 3 ? 12 : 0));
  }
  function laco() {
    while (proxTempo < ctx.currentTime + 0.14) {
      agendar(passoAtual, proxTempo);
      proxTempo += PASSO;
      passoAtual = (passoAtual + 1) % 64;
    }
  }

  /* ----- Controle liga/desliga e volume ----- */
  const ganho = () => Math.pow(volumePct / 100, 2) * 0.9;
  function notificar() { ouvintes.forEach((fn) => fn(tocando)); }

  function ligar() {
    if (tocando || !montar()) return;
    tocando = true;
    passoAtual = 0; proxTempo = ctx.currentTime + 0.08;
    volume.gain.cancelScheduledValues(ctx.currentTime);
    volume.gain.setValueAtTime(volume.gain.value, ctx.currentTime);
    volume.gain.linearRampToValueAtTime(ganho(), ctx.currentTime + 0.6);   // fade-in
    relogio = setInterval(laco, 30);
    PA7.guardar.gravar('radio', true);
    notificar();
  }
  function desligar() {
    if (!tocando) return;
    tocando = false;
    volume.gain.cancelScheduledValues(ctx.currentTime);
    volume.gain.setValueAtTime(volume.gain.value, ctx.currentTime);
    volume.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.25);        // fade-out
    setTimeout(() => { if (!tocando) clearInterval(relogio); }, 320);
    PA7.guardar.gravar('radio', false);
    notificar();
  }
  function definirVolume(pct) {
    volumePct = Math.max(0, Math.min(100, pct));
    PA7.guardar.gravar('radioVolume', volumePct);
    if (tocando) volume.gain.linearRampToValueAtTime(ganho(), ctx.currentTime + 0.08);
  }

  /* ----- Visualizador de barras (canvas) ----- */
  function desenhador(canvas) {
    const g = canvas.getContext('2d');
    const BARRAS = 30;
    const picos = new Array(BARRAS).fill(0);
    let ativo = true, dados = null;

    function ajustar() {
      const r = canvas.getBoundingClientRect(), d = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.max(1, r.width * d); canvas.height = Math.max(1, r.height * d);
    }
    ajustar();
    new ResizeObserver(ajustar).observe(canvas);

    function quadro() {
      if (!ativo || !canvas.isConnected) return;
      requestAnimationFrame(quadro);
      if (canvas.offsetParent === null) return;      // app escondido: não gasta CPU
      const w = canvas.width, h = canvas.height;
      g.clearRect(0, 0, w, h);
      if (analisador && !dados) dados = new Uint8Array(analisador.frequencyBinCount);
      if (analisador && tocando) analisador.getByteFrequencyData(dados);
      const larg = w / BARRAS;
      for (let i = 0; i < BARRAS; i++) {
        // idle: barrinhas baixas; tocando: espectro (graves à esquerda)
        let v = tocando && dados ? dados[Math.floor(2 + i * 1.25)] / 255 : 0.04;
        v = Math.pow(v, 1.25);
        picos[i] = Math.max(v, picos[i] - 0.012);
        const altura = Math.max(4, v * h * 0.95);
        const grad = g.createLinearGradient(0, h, 0, h - altura);
        grad.addColorStop(0, '#ff4f9a'); grad.addColorStop(0.55, '#ff8f6b'); grad.addColorStop(1, '#ffb347');
        g.fillStyle = grad;
        g.shadowColor = '#ff4f9a'; g.shadowBlur = 10 * (w / 400);
        g.fillRect(i * larg + larg * 0.14, h - altura, larg * 0.72, altura);
        g.shadowBlur = 0;
        g.fillStyle = '#ffb347';                      // "pico" ciano que cai devagar
        g.fillRect(i * larg + larg * 0.14, h - picos[i] * h * 0.95 - 5, larg * 0.72, 3);
      }
    }
    quadro();
    return () => { ativo = false; };
  }

  /* ----- Interface do app Rádio (chamada pelo celular.js) ----- */
  function montarApp(corpo) {
    corpo.innerHTML = `
      <div class="radio">
        <div class="radio__cartaz">
          <p class="radio__no-ar"><i class="radio__lampada" aria-hidden="true"></i><span id="radio-estado">Fora do ar</span></p>
          <h3 class="radio__nome">PA7 <span>FM</span></h3>
          <p class="radio__slogan">A rádio de quem constrói</p>
        </div>
        <canvas class="radio__viz" aria-hidden="true"></canvas>
        <div class="letreiro" role="marquee" aria-label="Locutor: ${PA7.dados.locutor}">
          <div class="letreiro__faixa" aria-hidden="true"><span>${PA7.dados.locutor}</span><span>${PA7.dados.locutor}</span></div>
        </div>
        <p class="radio__faixa">${PA7.icone('nota')}<span>Neon Overdrive <small>sintetizada ao vivo no seu navegador</small></span></p>
        <div class="radio__controles">
          <button class="radio__power" id="radio-power" type="button" aria-pressed="false" aria-label="Ligar a rádio"></button>
          <label class="radio__volume">
            <span>${PA7.icone('som')}<b class="so-leitor">Volume</b></span>
            <input id="radio-volume" type="range" min="0" max="100" step="1" value="${volumePct}" aria-label="Volume da rádio">
          </label>
        </div>
        <p class="radio__nota">Sem MP3: o beat é criado por código, em tempo real.</p>
      </div>`;
    const botao = PA7.$('#radio-power', corpo), slider = PA7.$('#radio-volume', corpo), estado = PA7.$('#radio-estado', corpo);
    const raiz = PA7.$('.radio', corpo);

    function pintar(on) {
      botao.setAttribute('aria-pressed', on);
      botao.setAttribute('aria-label', on ? 'Desligar a rádio' : 'Ligar a rádio');
      botao.innerHTML = PA7.icone(on ? 'pausa' : 'ligar') + `<span>${on ? 'Desligar' : 'Ligar'}</span>`;
      estado.textContent = on ? 'No ar' : 'Fora do ar';
      raiz.classList.toggle('radio--ligada', on);
    }
    pintar(tocando);
    ouvintes.add(pintar);
    botao.addEventListener('click', () => (tocando ? desligar() : ligar()));
    const cor = () => slider.style.setProperty('--v', slider.value + '%');
    slider.addEventListener('input', () => { definirVolume(+slider.value); cor(); });
    cor();
    desenhador(PA7.$('.radio__viz', corpo));
  }

  PA7.radio = {
    montarApp,
    ligar, desligar,
    alternar() { tocando ? desligar() : ligar(); },
    get tocando() { return tocando; },
    aoMudar(fn) { ouvintes.add(fn); },
    get estavaLigada() { return PA7.guardar.ler('radio', false); },
  };
})();
