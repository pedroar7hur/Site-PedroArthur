/* ==========================================================================
   cenario.js — Fundo da tela principal e PARALLAX.
   O fundo é a imagem hero em tela cheia (CSS); aqui só movemos as camadas
   em velocidades diferentes para dar profundidade ao mexer o mouse
   (ou o giroscópio no celular). Respeita prefers-reduced-motion.
   ========================================================================== */
(function () {
  const cenario = document.getElementById('cenario');
  const jogo = document.getElementById('jogo');
  PA7.$$('.camada').forEach((c) => c.style.setProperty('--k', c.dataset.prof || 0));
  if (PA7.reduzMovimento.matches) return;

  let alvoX = 0, alvoY = 0, x = 0, y = 0, rodando = false;
  function laco() {
    // Interpolação (lerp): aproxima o valor atual do alvo → movimento macio
    x += (alvoX - x) * 0.07; y += (alvoY - y) * 0.07;
    const v1 = x.toFixed(3), v2 = y.toFixed(3);
    cenario.style.setProperty('--px', v1); cenario.style.setProperty('--py', v2);
    jogo.style.setProperty('--px', v1); jogo.style.setProperty('--py', v2);
    if (Math.abs(alvoX - x) > 0.001 || Math.abs(alvoY - y) > 0.001) requestAnimationFrame(laco);
    else rodando = false;
  }
  function mover(nx, ny) {
    alvoX = nx; alvoY = ny;
    if (!rodando) { rodando = true; requestAnimationFrame(laco); }
  }
  window.addEventListener('pointermove', (e) => {
    if (e.pointerType === 'touch') return;
    mover((e.clientX / window.innerWidth - 0.5) * -2, (e.clientY / window.innerHeight - 0.5) * -2);
  }, { passive: true });
  window.addEventListener('deviceorientation', (e) => {
    if (e.gamma == null) return;
    mover(Math.max(-1, Math.min(1, -e.gamma / 25)), Math.max(-1, Math.min(1, -(e.beta - 45) / 25)));
  }, { passive: true });
})();
