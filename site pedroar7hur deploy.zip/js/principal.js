/* ==========================================================================
   principal.js — Orquestra tudo: tela de carregamento, "Press Start",
   atalhos de teclado, código Konami e confete.
   Este é o último script a carregar; os outros já criaram o namespace PA7.
   ========================================================================== */
(function () {
  const { $, $$ } = PA7;
  const body = document.body;
  let fase = 'carregando';        // 'carregando' → 'pronto' (aguarda Enter) → 'jogo'

  /* ------------------------------------------------------------------
     Preparação: logo em letras (para animar uma a uma) e ícones SVG
     ------------------------------------------------------------------ */
  function prepararLogo() {
    let i = 0;
    $$('.logo__linha').forEach((linha) => {
      const html = linha.innerHTML;       // ex.: 'AR<b class="logo__7">7</b>HUR'
      const tmp = document.createElement('div'); tmp.innerHTML = html;
      linha.textContent = '';
      Array.from(tmp.childNodes).forEach((no) => {
        if (no.nodeType === 3) {
          Array.from(no.textContent).forEach((ch) => {
            const s = document.createElement('span'); s.className = 'logo__letra'; s.textContent = ch; s.style.setProperty('--i', i++); s.setAttribute('aria-hidden', 'true'); linha.appendChild(s);
          });
        } else {
          no.classList.add('logo__letra'); no.style.setProperty('--i', i++); no.setAttribute('aria-hidden', 'true'); linha.appendChild(no);
        }
      });
    });
  }
  function hidratarIcones() {
    $$('[data-ico]').forEach((el) => { el.innerHTML = PA7.icone(el.dataset.ico); });
  }

  /* ------------------------------------------------------------------
     TELA DE CARREGAMENTO (~3s) com frases rotativas
     ------------------------------------------------------------------ */
  const elCarreg = $('#carregamento');
  const elBarra = $('#barra-carregamento');
  const elFrase = $('#frase-carregamento');
  const elStart = $('#btn-start');
  const elDica = $('#dica-pular');
  const DURACAO = PA7.reduzMovimento.matches ? 1200 : 3200;

  /* Progresso "de verdade": acelera, empaca um pouco e termina (parece carregamento real). */
  const TRECHOS = [[0, 0, 0], [0.30, 0.42, 1], [0.46, 0.47, 0], [0.80, 0.88, 1], [0.90, 0.90, 0], [1, 1, 1]]; // [tempo, progresso, suave?]
  function progresso(t) {
    for (let i = 1; i < TRECHOS.length; i++) {
      if (t <= TRECHOS[i][0]) {
        const [t0, p0] = TRECHOS[i - 1], [t1, p1] = TRECHOS[i];
        const u = (t - t0) / (t1 - t0);
        return p0 + (p1 - p0) * (1 - Math.pow(1 - u, 2));
      }
    }
    return 1;
  }

  let t0 = 0, fraseAtual = -1, rafCarreg = 0;
  function atualizarCarregamento(agora) {
    const t = Math.min(1, (agora - t0) / DURACAO);
    const p = progresso(t);
    elCarreg.style.setProperty('--p', p.toFixed(4));
    elBarra.setAttribute('aria-valuenow', Math.round(p * 100));
    const idx = Math.min(PA7.dados.frasesCarregamento.length - 1, Math.floor(t * PA7.dados.frasesCarregamento.length));
    if (idx !== fraseAtual) { fraseAtual = idx; elFrase.textContent = PA7.dados.frasesCarregamento[idx]; }
    if (t < 1) rafCarreg = requestAnimationFrame(atualizarCarregamento); else terminarCarregamento();
  }
  function terminarCarregamento() {
    if (fase !== 'carregando') return;
    cancelAnimationFrame(rafCarreg);
    fase = 'pronto';
    elCarreg.style.setProperty('--p', 1);
    elBarra.setAttribute('aria-valuenow', 100);
    elFrase.textContent = 'Tudo pronto. Funciona na sua máquina também.';
    elDica.hidden = true;
    elStart.hidden = false;
    elStart.focus({ preventScroll: true });
  }

  /* ------------------------------------------------------------------
     START: do carregamento para o jogo
     ------------------------------------------------------------------ */
  function comecar() {
    if (fase !== 'pronto') return;
    fase = 'jogo';
    PA7.som.contexto();            // o clique/tecla libera o áudio do navegador
    PA7.som.inicio();
    elCarreg.classList.add('saindo');
    body.classList.replace('fase-carregando', 'fase-jogo');
    setTimeout(() => { elCarreg.hidden = true; }, 1000);

    // Rádio ligada na última visita? Agora o navegador deixa tocar.
    if (PA7.radio.estavaLigada) PA7.radio.ligar();

    // Notificações de abertura, em cascata
    setTimeout(() => PA7.hud.notificar({ titulo: 'Nova missão desbloqueada', texto: 'Explorar Vice City e conhecer o Pedro.', tipo: 'missao', icone: 'missoes' }), 1300);
    setTimeout(() => PA7.hud.notificar({
      titulo: 'Dica rápida',
      texto: PA7.ehCelular() ? 'Toque nos apps do celular para explorar.' : 'Use o celular, o minimapa ou aperte T para abrir o terminal.',
      icone: 'ia', silencioso: true,
    }), 3600);
    setTimeout(() => $('#celular').focus({ preventScroll: true }), 1400);
  }
  // Um toque/clique na tela de carregamento: pula o carregamento, ou começa o jogo
  elCarreg.addEventListener('click', () => {
    if (fase === 'carregando') terminarCarregamento(); else if (fase === 'pronto') comecar();
  });

  /* ------------------------------------------------------------------
     CONFETE neon (código Konami)
     ------------------------------------------------------------------ */
  function confete() {
    if (PA7.reduzMovimento.matches) return;
    const canvas = $('#confete'), g = canvas.getContext('2d');
    const d = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = innerWidth * d; canvas.height = innerHeight * d;
    g.scale(d, d);
    const cores = ['#ff2d95', '#ff8a3d', '#ffd23f', '#22e4ff', '#9b5cff', '#39ff88'];
    const pecas = Array.from({ length: 200 }, () => ({
      x: Math.random() * innerWidth, y: -20 - Math.random() * innerHeight * 0.6,
      vx: (Math.random() - 0.5) * 5, vy: 2 + Math.random() * 5,
      w: 6 + Math.random() * 8, h: 3 + Math.random() * 6, r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4,
      cor: cores[Math.floor(Math.random() * cores.length)],
    }));
    const inicio = performance.now();
    (function quadro(agora) {
      const t = agora - inicio;
      g.clearRect(0, 0, innerWidth, innerHeight);
      pecas.forEach((p) => {
        p.vy += 0.09; p.x += p.vx; p.y += p.vy; p.r += p.vr;
        g.save(); g.translate(p.x, p.y); g.rotate(p.r);
        g.globalAlpha = Math.max(0, 1 - Math.max(0, t - 3200) / 1200);
        g.shadowColor = p.cor; g.shadowBlur = 10; g.fillStyle = p.cor;
        g.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        g.restore();
      });
      if (t < 4400) requestAnimationFrame(quadro); else g.clearRect(0, 0, innerWidth, innerHeight);
    })(inicio);
  }

  /* ------------------------------------------------------------------
     CÓDIGO KONAMI  ↑ ↑ ↓ ↓ ← → ← → B A
     ------------------------------------------------------------------ */
  const KONAMI = ['arrowup', 'arrowup', 'arrowdown', 'arrowdown', 'arrowleft', 'arrowright', 'arrowleft', 'arrowright', 'b', 'a'];
  let posKonami = 0;
  let cheatAtivo = false;

  function ativarCheat() {
    // Se o código foi digitado dentro do terminal, remove o "ba" que sobrou no campo
    const campo = PA7.terminal.campo;
    if (document.activeElement === campo) campo.value = campo.value.replace(/ba$/i, '');
    PA7.hud.dinheiro.cheat();
    confete();
    PA7.som.estrela();
    if (!cheatAtivo) {
      cheatAtivo = true;
      PA7.hud.notificar({ titulo: 'Modo cheat ativado', texto: 'Dinheiro infinito. Trapacear também é um jeito de chegar lá.', tipo: 'dinheiro', icone: 'controle', silencioso: true });
    }
    PA7.procurado.encontrar('ovo-konami');
  }
  function verificarKonami(e) {
    const tecla = e.key.length === 1 ? e.key.toLowerCase() : e.key.toLowerCase();
    if (tecla === KONAMI[posKonami]) {
      posKonami++;
      if (posKonami === KONAMI.length) { posKonami = 0; ativarCheat(); }
    } else {
      posKonami = tecla === KONAMI[0] ? 1 : 0;
    }
  }

  /* ------------------------------------------------------------------
     TECLADO GLOBAL
     ------------------------------------------------------------------ */
  document.addEventListener('keydown', (e) => {
    if (fase === 'carregando' && e.key === 'Enter') { e.preventDefault(); terminarCarregamento(); return; }
    if (fase === 'pronto' && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); comecar(); return; }
    if (fase !== 'jogo' || e.repeat) return;

    verificarKonami(e);

    const emCampo = e.target.closest && e.target.closest('input, textarea, select, [contenteditable="true"]');
    const bloqueado = body.classList.contains('terminal-aberto') || body.classList.contains('modal-aberto');

    if (e.key === 'Escape' && !bloqueado) {
      if (PA7.celular.rodaAberta) PA7.celular.fecharRoda(false);
      else if (PA7.celular.appAtual) PA7.celular.voltar();
      else PA7.celular.guardar();
      return;
    }
    if (emCampo || bloqueado || e.ctrlKey || e.metaKey || e.altKey) return;

    if (e.key === 't' || e.key === 'T') { e.preventDefault(); PA7.terminal.abrir(); }
    else if (e.key === 'ArrowUp' && PA7.celular.guardado) { e.preventDefault(); PA7.celular.mostrar(); }
  }, true);

  /* ------------------------------------------------------------------
     Botões do HUD
     ------------------------------------------------------------------ */
  function configurarSom() {
    const btn = $('#btn-som'), icone = $('.hud__botao-icone', btn);
    function pintar() {
      const on = PA7.som.ativo;
      btn.setAttribute('aria-pressed', on);
      btn.setAttribute('aria-label', 'Efeitos sonoros: ' + (on ? 'ligados' : 'desligados'));
      icone.innerHTML = PA7.icone(on ? 'som' : 'mudo');
    }
    btn.addEventListener('click', () => { PA7.som.definirAtivo(!PA7.som.ativo); pintar(); if (PA7.som.ativo) PA7.som.notificar(); });
    pintar();
  }
  function configurarRadioMini() {
    const mini = $('#radio-mini');
    PA7.radio.aoMudar((on) => { mini.hidden = !on; });
    mini.addEventListener('click', () => PA7.celular.abrir('radio'));
  }

  /* ------------------------------------------------------------------
     INICIALIZAÇÃO
     ------------------------------------------------------------------ */
  prepararLogo();
  hidratarIcones();
  PA7.hud.iniciar();
  PA7.hud.estrelas.definir(PA7.procurado.estrelas);
  PA7.celular.iniciar();
  PA7.hud.montarMinimapa(PA7.celular.apps, (id) => PA7.celular.abrir(id));
  (function missaoAtual() {   // card do centro: alterna entre as missões em andamento
    const lista = PA7.dados.missoes.andamento.map((m) => m.titulo); let k = 0; const el = $('#missao-atual-titulo');
    el.textContent = lista[0];
    setInterval(() => { k = (k + 1) % lista.length; el.textContent = lista[k]; }, 6000);
  })();
  configurarSom();
  configurarRadioMini();

  // Se a tela virar "celular" (ex.: girar o aparelho), o celular nunca fica guardado
  window.matchMedia('(max-width: 820px)').addEventListener('change', (e) => { if (e.matches) PA7.celular.mostrar(); });

  t0 = performance.now();
  rafCarreg = requestAnimationFrame(atualizarCarregamento);
})();
